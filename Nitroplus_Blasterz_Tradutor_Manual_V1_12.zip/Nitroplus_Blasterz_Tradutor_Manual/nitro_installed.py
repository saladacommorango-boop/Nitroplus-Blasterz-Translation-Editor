"""Leitura SEM INSTALAÇÃO de arquivos de Nitroplus Blasterz já traduzidos.

Aceita a pasta data, arquivos individuais (inclusive cópias Windows com
sufixo (1)/(2)) e ZIP com os arquivos TDF/BMF do jogo. O texto é comparado
com o TDF EN ORIGINAL verificado e só é aceito se reconstruir byte a byte.
Nenhum dado é gravado ou extraído durante a leitura.
"""
from pathlib import Path
import re
import zipfile

import nitro_core as core
import nitro_project as project

# Hashes das fontes produzidas pelo patch 1.0 e pelas versões 1.9/1.10
# do editor. Fontes de outras traduções NÃO são alteradas nem "corrigidas".
KNOWN_PT_FONT_SHA = {
    core.FONT03_NAME:'55ae305e5e01a73c5f4cbdfa1898bca80283c01036eba3f3ea7e448d2d10b908',
    core.FONT04_NAME:'9236f7565d9de9baa8c2c751657b4014fb685963a3de149016779f1406497891',
}
GAME_FILES=(core.EN_NAME,core.FONT03_NAME,core.FONT04_NAME)


def canonical_game_name(filename):
    """Identifica nomes originais e cópias como TDF(2), BMF(1)."""
    base=Path(filename.replace('\\','/')).name
    for target in GAME_FILES:
        if re.fullmatch(re.escape(target)+r'(?:\s*\(\d{1,5}\))?', base, re.I):
            return target
    return None


def _decode_contents(contents,en):
    if core.EN_NAME not in contents:
        raise ValueError('Não foi selecionado o arquivo de TEXTO traduzido '+core.EN_NAME)
    for name,raw in contents.items():
        if len(raw)>core.MAX_FILE_SIZE:
            raise ValueError('Arquivo acima do tamanho seguro: '+name)
        if name != core.EN_NAME:
            digest=core.sha(raw)
            allowed={KNOWN_PT_FONT_SHA[name],core.KNOWN_SHA[name]}
            if digest not in allowed:
                raise ValueError('Fonte desconhecida ou corrompida: '+name+'\n'
                    'Nenhum arquivo foi instalado ou alterado. Selecione as fontes originais'
                    ' ou aquelas geradas pelo editor e pela tradução 1.0.')
    tr,notes,erase=project.read_generated_tdf_bytes(contents[core.EN_NAME],en)
    details=[]
    for name in (core.FONT03_NAME,core.FONT04_NAME):
        if name in contents:
            label='fonte PT-BR verificada' if core.sha(contents[name])==KNOWN_PT_FONT_SHA[name] else 'fonte original verificada'
            details.append(name+': '+label)
    if not details:
        details.append('Fontes não selecionadas; somente texto TDF verificado.')
    return tr,notes,erase,details


def read_installed_files(paths,en):
    """Recebe 1 a 3 caminhos selecionados, sem alterar os dados originais."""
    contents={}
    for selected in paths:
        p=Path(selected)
        key=canonical_game_name(p.name)
        if key is None:
            raise ValueError('Arquivo não reconhecido: '+p.name)
        if key in contents:
            raise ValueError('Duas cópias do mesmo arquivo foram selecionadas: '+key)
        if p.is_symlink() or not p.is_file():
            raise ValueError('Selecione um arquivo regular, não atalho: '+str(p))
        if p.stat().st_size>core.MAX_FILE_SIZE:
            raise ValueError('Arquivo muito grande: '+p.name)
        contents[key]=p.read_bytes()
    return _decode_contents(contents,en)


def read_installed_folder(folder,en):
    """Procura os nomes originais em data (ou os nomes copiados com sufixo)."""
    root=Path(folder)
    if not root.is_dir() or root.is_symlink():
        raise ValueError('Pasta inválida para leitura')
    data=root/'data'
    if data.is_dir():
        root=data
    selected={}
    for p in root.iterdir():
        if not p.is_file() or p.is_symlink():
            continue
        key=canonical_game_name(p.name)
        if key is None: continue
        if key in selected:
            raise ValueError('A pasta contém mais de uma cópia de '+key+';'
                ' selecione os arquivos manualmente para evitar ambiguidade.')
        selected[key]=p
    return read_installed_files(selected.values(),en)


def read_installed_zip(path,en):
    """ZIP criado pelo usuário com TDF e fontes, sem extrair ou executar nada."""
    contents={}
    with zipfile.ZipFile(path) as z:
        if len(z.infolist())>10000:
            raise ValueError('ZIP com entradas demais')
        for member in z.infolist():
            if member.is_dir():continue
            key=canonical_game_name(member.filename)
            if key is None: continue
            if key in contents:
                raise ValueError('ZIP contém dois arquivos com a mesma função: '+key)
            if member.file_size>core.MAX_FILE_SIZE:
                raise ValueError('Arquivo compactado acima do limite: '+key)
            raw=z.read(member)
            if len(raw)!=member.file_size:
                raise ValueError('Arquivo descompactado com tamanho divergente')
            contents[key]=raw
    return _decode_contents(contents,en)
