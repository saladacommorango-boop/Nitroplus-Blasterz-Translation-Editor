#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Editor visual PT-BR de Nitroplus Blasterz, sem arquivos de jogo embutidos."""
import argparse
from pathlib import Path
import sys
import unicodedata
import zipfile

import nitro_core as core
import nitro_patch10 as patch10
import nitro_sources as sources
import nitro_project as project
import nitro_installed as installed


def cli():
    parser = argparse.ArgumentParser(description='Nitroplus Blasterz — editor/extrator/reinseridor seguro de TDF')
    sub = parser.add_subparsers(dest='command')
    ex = sub.add_parser('extrair', help='Exporta CSV JP/EN com 4192 registros')
    ex.add_argument('--data',required=True,help='Pasta de backup dos originais (4 recomendados; JP opcional)')
    ex.add_argument('--csv',required=True,help='Nome NOVO de CSV (não sobrescreve)')
    ex.add_argument('--delta-vj51',help='Importa revisões PT da VJ51 oficial para o CSV')
    build = sub.add_parser('gerar', help='Valida CSV e gera TDF + fontes em pasta separada')
    build.add_argument('--data',required=True)
    build.add_argument('--csv',required=True)
    build.add_argument('--saida',required=True,help='Pasta de saída diferente da pasta data')
    build.add_argument('--sem-fontes', action='store_true',help='Gerar somente TDF; acentos PT podem falhar no jogo!')
    check = sub.add_parser('verificar', help='Valida originais, CSV opcional')
    check.add_argument('--data',required=True)
    check.add_argument('--csv')
    args = parser.parse_args()
    if args.command is None:
        if len(sys.argv) > 1:
            parser.print_help()
        else:
            gui()
        return
    base, en, jp = core.load_backup_sources(args.data)
    print('Backup original: compatível. JP opcional. Entradas: 4192. UTF-16LE: OK.')
    if args.command == 'extrair':
        translation={}
        if args.delta_vj51:
            translation=core.load_vj51_delta(args.delta_vj51,en)
        core.write_csv(args.csv,core.records(en,jp,translation))
        print('CSV criado:',args.csv,'PT-BR preenchidos:',len(translation))
    elif args.command == 'verificar':
        if args.csv:
            trans, notes, erase = core.read_csv(args.csv,en,jp)
            b, changed, warning = core.make_build(en, trans, erase)
            print('CSV íntegro | Preenchidos:',len(trans),'| APAGAR:',len(erase),
                  '| Mudanças reais:',len(changed),'| Avisos:',len(warning),'| SHA final:',core.sha(b))
            for w in warning[:100]:print('AVISO:',w)
        else:
            print('Fontes não verificadas; use GERAR para conferir BMF03/04.')
    elif args.command == 'gerar':
        trans, notes, erase = core.read_csv(args.csv,en,jp)
        manifest=core.create_outputs(base,args.saida,en,jp,trans,erase,make_fonts=not args.sem_fontes)
        print('Arquivos gerados SEM instalar:',args.saida)
        print('Modificados:',manifest['registros_modificados'], 'avisos:',len(manifest['avisos']))
        print('SHA novo TDF:',manifest['arquivos_gerados'][core.EN_NAME])
        for w in manifest['avisos'][:100]:print('AVISO:',w)


def gui():
    import tkinter as tk
    from tkinter import ttk, filedialog, messagebox
    from tkinter import font as tkfont

    root=tk.Tk()
    root.title('Nitroplus Blasterz - Tradutor Manual')
    root.geometry('1180x800')
    root.minsize(940,650)

    base=None
    en=None
    jp=None
    allrecs=[]
    translations={}
    notes={}
    erasures=set()
    current=None
    changed_form=False
    csv_path=None
    project_path=None
    backup_directory=Path.home()/'Nitroplus_Editor_Backups'
    char_count_var=tk.StringVar(value='Selecione um registro para começar')
    vn_estimate_var=tk.StringVar(value='S1/S2: até três linhas estimadas | S3: edição livre')
    glyph_alert_var=tk.StringVar(value='Caracteres sem suporte aparecerão aqui')
    jp_caption_var=tk.StringVar(value='Japonês original (opcional — requer arquivo JP)')

    folder_var=tk.StringVar(value='Abra uma tradução com seu backup original (EN, duas fontes e JP recomendado)')
    query_var=tk.StringVar()
    section_var=tk.StringVar(value='Todas')
    status_filter_var=tk.StringVar(value='Todos')
    erase_var=tk.BooleanVar(value=False)
    stats_var=tk.StringVar(value='Nenhum arquivo carregado. Instalação somente com confirmação e backup.')
    title=tk.Label(root,text='Nitroplus Blasterz — Revisão Humana JP / EN / PT-BR',font=('Segoe UI',16,'bold'))
    title.pack(anchor='w',padx=14,pady=(11,3))
    top=ttk.Frame(root)
    top.pack(fill='x',padx=14,pady=(0,7))
    ttk.Label(top,textvariable=folder_var).pack(side='left',fill='x',expand=True)

    toolbar=ttk.Frame(root)
    toolbar.pack(fill='x',padx=14,pady=(2,8))
    def set_note(t):
        stats_var.set(t)

    def key_for_row(row):
        return (int(row['secao']),int(row['indice_0']))

    def clear_editor():
        for txt in (enbox,jpbox,note_box):
            txt.configure(state='normal')
            txt.delete('1.0','end')
        vn_assign('')
        for txt in (enbox,jpbox):txt.configure(state='disabled')
        erase_var.set(False)

    def get_widget(txt):
        return txt.get('1.0','end-1c')

    def save_current():
        nonlocal changed_form
        if current is None or en is None:
            return
        pt=get_widget(ptbox)
        obs=get_widget(note_box)
        if erase_var.get():
            if pt.strip():
                raise ValueError('Apagar exige campo PT-BR vazio. Limpe o texto primeiro.')
            erasures.add(current)
            translations.pop(current,None)
        else:
            erasures.discard(current)
            if pt:
                core.check_translation(pt,current)
                translations[current]=pt
            else:
                translations.pop(current,None)
        if obs:
            notes[current]=obs
        else:
            notes.pop(current,None)
        changed_form=False

    def load_row(k):
        nonlocal current,changed_form
        current=k
        if k is None:
            clear_editor()
            return
        s, i=k
        txt_en=en[s-1].texts[i]
        txt_jp=jp[s-1].texts[i]
        if base is not None and (Path(base)/core.JP_NAME).is_file():
            jp_caption_var.set('Japonês original (somente leitura)')
        else:
            jp_caption_var.set('Japonês não disponível — acrescente o arquivo JP original ao backup')
        for txt, data in ((enbox,txt_en),(jpbox,txt_jp)):
            txt.configure(state='normal')
            txt.delete('1.0','end');txt.insert('1.0',data);txt.configure(state='disabled')
        set_section_edit_mode(s)
        vn_assign(translations.get(k,''),allow_existing=True)
        note_box.delete('1.0','end');note_box.insert('1.0',notes.get(k,''))
        erase_var.set(k in erasures)
        id_label.configure(text='S{}_{:04d} | {} | UTF-16: {} unidades em EN'.format(s,i,('Narrativa' if s==1 else 'Outra História' if s==2 else 'Interface'),len(txt_en.encode('utf-16le'))//2))
        update_counter()
        changed_form=False

    def row_status(k):
        if k in erasures:return 'APAGAR'
        if k in translations:return 'PT-BR'
        return 'EN original'

    def refresh_rows(select=None):
        if en is None:
            return
        search=query_var.get().casefold().strip()
        secf=section_var.get()
        statf=status_filter_var.get()
        tree.delete(*tree.get_children())
        for row in allrecs:
            k=key_for_row(row)
            st=row_status(k)
            if secf!='Todas' and secf!='S'+str(k[0]):continue
            if statf=='Com tradução' and st=='EN original':continue
            if statf=='Sem tradução' and st!='EN original':continue
            if statf=='Apagar' and st!='APAGAR':continue
            if search:
                pool=' '.join([row['id'],core.unescape_cell(row['ingles']),
                               core.unescape_cell(row['japones']),translations.get(k,''),notes.get(k,'')]).casefold()
                if search not in pool:continue
            preview=core.unescape_cell(row['ingles']).replace('\n',' ↵ ').replace('\r','')
            tree.insert('', 'end', iid=row['id'],values=(row['id'], st, preview[:150]))
        if select is not None:
            iid='S{}_{:04d}'.format(*select)
            if tree.exists(iid):
                tree.selection_set(iid)
                tree.see(iid)
        n=len(tree.get_children())
        set_note('Exibindo {}/4192 | PT preenchidos {} | Apagar {} | {}' .format(n,len(translations),len(erasures),base or 'sem dados'))

    def on_select(event=None):
        nonlocal current
        selected=tree.selection()
        if not selected:
            return
        rid=selected[0]
        s,i=int(rid[1]),int(rid[3:])
        k=(s,i)
        if current==k:return
        previous_key=current
        try:
            save_current()
            if previous_key is not None:
                prev_id='S{}_{:04d}'.format(*previous_key)
                if tree.exists(prev_id):
                    oldvals=tree.item(prev_id,'values')
                    tree.item(prev_id,values=(prev_id,row_status(previous_key),oldvals[2]))
        except Exception as exc:
            messagebox.showerror('Texto inválido',str(exc))
            if current is not None:
                previous='S{}_{:04d}'.format(*current)
                if tree.exists(previous):tree.selection_set(previous)
            return
        load_row(k)
        if tree.exists(rid):
            tree.item(rid,values=(rid,row_status(k),tree.item(rid,'values')[2]))

    def on_search(*_):
        # Só atualizar automaticamente filtros quando o editor atual é válido.
        try:save_current()
        except ValueError:return
        refresh_rows(current)

    def choose_game():
        nonlocal base,en,jp,allrecs,translations,notes,erasures,current,csv_path,project_path
        path=filedialog.askdirectory(title='Selecione a pasta do backup original (4 arquivos recomendados)')
        if not path:return
        try:
            if en is not None and not messagebox.askyesno('Abrir outros arquivos?','As traduções em memória serão substituídas. Exporte um CSV antes, se precisar. Continuar?'):
                return
            newroot,newen,newjp=sources.import_backup_folder(path)
        except Exception as exc:
            messagebox.showerror('Originais incompatíveis',str(exc)+'\n\nEscolha a pasta de backup com os arquivos ORIGINAIS, copiados antes de instalar a tradução. Não use a pasta data já traduzida.');return
        base,en,jp=newroot,newen,newjp
        translations={};notes={};erasures=set();current=None;csv_path=None;project_path=None
        allrecs=core.records(en,jp)
        folder_var.set('Backup original verificado: '+str(base))
        clear_editor()
        refresh_rows()
        if tree.get_children():tree.selection_set(tree.get_children()[0]);on_select()
        messagebox.showinfo('Extração validada','Backup original íntegro: 4.192 registros. JP opcional. Nenhum arquivo do jogo foi alterado.')

    def request_verified_sources():
        """Pasta de backup é a opção principal; JP é recomendado."""
        if en is not None:
            return base,en,jp
        cached=sources.known_cached_sources()
        if cached is not None:
            return cached
        backup_mode=messagebox.askyesnocancel('Backup dos arquivos originais',
            'Selecione o BACKUP LIMPO feito ANTES de instalar a tradução.\n\n'
            'SIM: escolher a PASTA com os originais (recomendado).\n'
            'NÃO: escolher um ZIP contendo os originais.\n'
            'CANCELAR: voltar sem abrir.\n\n'
            'Backup recomendado: texto inglês + 2 fontes + texto japonês.\n'
            'O japonês é opcional; sem ele, a coluna JP fica vazia.\n'
            'O ZIP da tradução 1.0 também pode ser aberto com esse backup.')
        if backup_mode is None:return None
        if backup_mode:
            folder=filedialog.askdirectory(title='Selecione a PASTA com os originais (4 arquivos recomendados)')
            return sources.import_backup_folder(folder) if folder else None
        zp=filedialog.askopenfilename(title='Selecione o ZIP de backup dos originais',
            filetypes=[('ZIP de backup','*.zip'),('Todos','*.*')])
        return sources.import_backup_zip(zp) if zp else None

    def import_installed():
        """Abre o TDF instalado e suas fontes com seleção por pasta ou arquivos."""
        nonlocal base,en,jp,allrecs,translations,notes,erasures,current,csv_path,project_path
        mode=messagebox.askyesnocancel('Abrir tradução INSTALADA',
            'Como deseja selecionar os arquivos já traduzidos?\n\n'
            'SIM: selecionar a pasta data do Nitroplus (ou pasta com os três arquivos).\n'
            'NÃO: selecionar o texto e as duas fontes individualmente (Ctrl+clique).\n'
            'CANCELAR: voltar ao editor.\n\n'
            'Aceitamos também cópias com sufixos (1), (2) etc.')
        if mode is None:return
        if mode:
            selected=filedialog.askdirectory(title='Selecione a pasta com a tradução instalada')
            if not selected:return
        else:
            selected=filedialog.askopenfilenames(
                title='Selecione o texto instalado e opcionalmente as duas fontes (Ctrl+clique)',
                filetypes=[('Arquivos instalados, inclusive sem extensão','*'),('Todos','*.*')])
            if not selected:return
        try:
            if en is not None:save_current()
            origin=request_verified_sources()
            if origin is None:return
            rbase,ren,rjp=origin
            if mode:
                tr,newnotes,newerasures,details=installed.read_installed_folder(selected,ren)
                where='pasta data instalada'
            else:
                tr,newnotes,newerasures,details=installed.read_installed_files(selected,ren)
                where='arquivos instalados selecionados'
            if en is not None and not messagebox.askyesno('Substituir revisão atual?',
                'Abrir {} com {} traduções e {} apagamentos?\n\n'
                'Salve antes seu projeto ou CSV para preservar alterações não exportadas.'.format(
                    where,len(tr),len(newerasures))):return
        except Exception as exc:
            return messagebox.showerror('Falha ao ler tradução instalada',
                str(exc)+'\n\nEscolha a pasta data com os arquivos INSTALADOS, ou selecione o texto e as fontes. '
                'Para comparar o EN, selecione seu backup original (EN, duas fontes e JP recomendado).')
        base,en,jp=rbase,ren,rjp
        allrecs=core.records(en,jp)
        folder_var.set('Tradução instalada lida; backup original verificado: '+str(base))
        translations=tr;notes=newnotes;erasures=newerasures
        csv_path=None;project_path=None;current=None
        clear_editor();refresh_rows()
        if tree.get_children():
            tree.selection_set(tree.get_children()[0]);on_select()
        messagebox.showinfo('Arquivos instalados abertos',
            '{}: {} traduções, {} apagamentos.\n\n{}\n\n'
            'Compare JP/EN/PT, edite e salve como projeto ou CSV. '
            'Nada foi modificado no jogo.'.format(where,len(tr),len(newerasures),'\n'.join(details)))

    def import_any():
        """Um só caminho para 1.0, projetos do próprio editor, CSV e TDF gerado."""
        nonlocal base,en,jp,allrecs,translations,notes,erasures,current,csv_path,project_path
        path=filedialog.askopenfilename(
            title='Abrir tradução 1.0 (ZIP), projeto, CSV ou arquivo TDF',
            filetypes=[('Tradução / projeto / tabela','*.zip *.ntproj *.csv *.tdf'),
                       ('Todos os arquivos (inclui TDF sem extensão)','*')])
        if not path:return
        f=Path(path)
        try:
            if en is not None:
                save_current()
            origins=request_verified_sources()
            if origins is None:return
            rbase, ren, rjp=origins
            label=''
            newnotes={}; newerasures=set()
            newcsv=None; newproject=None
            if f.suffix.lower()=='.csv':
                tr,newnotes,newerasures=core.read_csv(f,ren,rjp)
                label='CSV do editor';newcsv=f
            elif f.suffix.lower()=='.ntproj':
                tr,newnotes,newerasures=project.read_project(f,ren,rjp)
                label='projeto do editor';newproject=f
            elif f.suffix.lower()=='.json':
                tr=core.load_vj51_delta(f,ren)
                label='formato antigo'
            elif zipfile.is_zipfile(f):
                with zipfile.ZipFile(f) as z:
                    members=set(z.namelist())
                if project.PROJECT_MEMBER in members:
                    tr,newnotes,newerasures=project.read_project(f,ren,rjp)
                    label='projeto do editor';newproject=f if f.suffix.lower()=='.ntproj' else None
                elif 'MANIFESTO_1_0.json' in members:
                    tr,newerasures=patch10.read_10_texts(f,rbase,ren)
                    label='instalador PT-BR 1.0 (verificado)'
                elif 'DELTA_PTBR_VJ51.json' in members:
                    tr=core.load_vj51_delta(f,ren)
                    label='formato antigo'
                else:
                    tr,newnotes,newerasures,details=installed.read_installed_zip(f,ren)
                    label='ZIP com arquivos da tradução instalada (TDF/fontes)'
            else:
                tr,newnotes,newerasures=project.read_generated_tdf(f,ren)
                label='arquivo TDF gerado'
            if en is not None and not messagebox.askyesno('Substituir revisão atual?',
                'Abrir {} com {} entradas traduzidas?\n\nAs alterações ainda não salvas serão substituídas.\n'
                'Salve um CSV ou projeto antes, se precisar.'.format(label,len(tr))):
                return
        except Exception as exc:
            return messagebox.showerror('Não foi possível abrir a tradução',
                str(exc)+'\n\nO instalador 1.0 é aceito diretamente, SEM usar VJ51. '
                'Na primeira utilização selecione um backup com os originais do jogo, '
                'porque o ZIP 1.0 contém apenas diferenças binárias. JP é opcional.')
        base,en,jp=rbase,ren,rjp
        allrecs=core.records(en,jp)
        folder_var.set('Backup original verificado: '+str(base))
        translations=tr;notes=newnotes;erasures=newerasures
        csv_path=newcsv;project_path=newproject;current=None
        clear_editor();refresh_rows()
        if tree.get_children():
            tree.selection_set(tree.get_children()[0]);on_select()
        messagebox.showinfo('Revisão aberta',
            '{}: {} traduções, {} apagamentos e {} observações.\n\n'
            'Edite, salve um CSV ou projeto .ntproj, ou gere o TDF para testar.\n'
            'Nenhum arquivo do jogo foi instalado.'.format(label,len(tr),len(newerasures),len(newnotes)))

    def import_csv():
        # Mantido como alias por compatibilidade de chamadas antigas.
        import_any()

    def export_project(path_override=None):
        nonlocal project_path
        if en is None:return messagebox.showwarning('Sem backup','Abra uma tradução usando o backup dos arquivos originais primeiro.')
        try:save_current()
        except Exception as exc:return messagebox.showerror('Texto inválido',str(exc))
        if path_override:
            p=Path(path_override)
        else:
            target=filedialog.asksaveasfilename(title='Salvar projeto de revisão do editor',
                defaultextension='.ntproj',
                initialfile=project_path.name if project_path else 'Nitroplus_Minha_Revisao.ntproj',
                filetypes=[('Projeto Nitroplus','*.ntproj')])
            if not target:return
            p=Path(target)
            if p.exists() and not messagebox.askyesno('Preservar projeto anterior',
                'Salvar por cima deste projeto? O editor guardará um backup numerado.'):
                return
        try:
            backup=project.save_project(p,en,jp,translations,notes,erasures)
            reread=project.read_project(p,en,jp)
            if reread!=(translations,notes,erasures):
                raise IOError('O projeto reaberto não corresponde às alterações em memória')
            project_path=p
            if path_override:
                set_note('Projeto salvo: {} | Backup: {}'.format(p,backup or 'primeiro salvamento'))
            else:
                messagebox.showinfo('Projeto salvo e conferido',
                    'Projeto salvo e reaberto:\n{}\n\nBackup: {}\n\n'
                    'Para editar depois, use Abrir tradução/projeto.'.format(p,backup or '(primeiro salvamento)'))
            return True
        except Exception as exc:
            messagebox.showerror('Falha ao salvar projeto',str(exc))
            return False

    def export_csv(path_override=None):
        nonlocal csv_path
        if en is None:return messagebox.showwarning('Sem arquivos','Carregue backup original EN + fontes primeiro.')
        try:save_current()
        except Exception as exc:return messagebox.showerror('Texto inválido',str(exc))
        if path_override:
            p=path_override
        else:
            p=filedialog.asksaveasfilename(title='Salvar tabela de trabalho CSV',defaultextension='.csv',initialfile=csv_path.name if csv_path else 'Nitroplus_PTBR_Revisao.csv',filetypes=[('CSV UTF-8','*.csv')])
        if not p:return
        p=Path(p)
        if p.exists() and path_override is None:
            if not messagebox.askyesno('Backup automático','Este CSV já existe.\nUma cópia de segurança .backup_N será preservada.\n\nSalvar a revisão atual nesse CSV?'):return
        try:
            lines=core.records(en,jp,translations,notes,erasures)
            backup=core.save_csv_with_backup(p,lines)
            # Reabrir, validar todas as referências e confirmar semântica antes de informar sucesso.
            rt,nn,ee=core.read_csv(p,en,jp)
            if rt!=translations or nn!=notes or ee!=erasures:
                raise IOError('CSV reaberto não corresponde às traduções; veja backup.')
            csv_path=p
            if path_override:
                set_note('CSV salvo: {} | Backup: {}'.format(p,backup or 'primeiro salvamento'))
            else:
                messagebox.showinfo('Tabela salva e conferida','CSV salvo e reaberto com sucesso!\n'+str(p)+'\n\nBackup: '+str(backup or '(novo arquivo)'))
            return True
        except Exception as exc:
            messagebox.showerror('Não foi possível salvar',str(exc))
            return False

    def save_shortcut(event=None):
        if project_path is not None:
            export_project(project_path)
        elif csv_path is not None:
            export_csv(csv_path)
        else:
            export_csv()
        return 'break'

    root.bind('<Control-s>',save_shortcut)

    def validate():
        if en is None:return messagebox.showwarning('Sem arquivos','Carregue backup original EN + fontes primeiro.')
        try:
            save_current()
            result, changed, warnings=core.make_build(en,translations,erasures)
            messagebox.showinfo('Auditoria TDF','Arquivo estruturalmente válido.\nRegistros alterados: {}\nEntradas PT-BR: {}\nApagar: {}\nAvisos de comprimento: {}\n\nSHA-256 da saída:\n{}\n\nAtenção: isto não substitui teste dentro do jogo.'.format(len(changed),len(translations),len(erasures),len(warnings),core.sha(result)))
        except Exception as exc:messagebox.showerror('Falha na auditoria',str(exc))

    def build():
        if en is None:return messagebox.showwarning('Sem arquivos','Carregue backup original EN + fontes primeiro.')
        try:save_current()
        except Exception as exc:return messagebox.showerror('Texto inválido',str(exc))
        p=filedialog.askdirectory(title='Escolha uma pasta de SAÍDA NOVA e separada do jogo')
        if not p:return
        if not messagebox.askyesno('Gerar arquivos sem instalar','Gerar TDF e fontes PT em:\n'+p+'\n\nA ferramenta NÃO modificará nenhum arquivo original.\nO jogo deve usar as fontes geradas para os acentos.'):return
        try:
            manifest=core.create_outputs(base,p,en,jp,translations,erasures,make_fonts=True)
            messagebox.showinfo('Geração concluída','Arquivos gerados, lidos e verificados.\n\nRegistros modificados: {}\nAvisos para revisão visual: {}\n\nDestino: {}\n\nNADA foi instalado no jogo. '.format(manifest['registros_modificados'],len(manifest['avisos']),p))
        except Exception as exc:messagebox.showerror('Geração interrompida',str(exc))

    def install_in_game():
        nonlocal base
        if en is None:
            return messagebox.showwarning('Sem backup','Abra a tradução usando seu backup dos arquivos originais.')
        try:save_current()
        except Exception as exc:return messagebox.showerror('Revisão inválida',str(exc))
        # Forçar CSV conferido antes de tocar no jogo. Cancelamento = não instalar.
        if export_csv(csv_path) is not True:
            return
        game=filedialog.askdirectory(title='Escolha a pasta do Nitroplus Blasterz (ou a pasta data)')
        if not game:return
        try:
            game_data=core._game_data_root(game)
            backup=core._backup_root_check(backup_directory,game_data)
        except Exception as exc:
            return messagebox.showerror('Pasta do jogo inválida',str(exc))
        if not messagebox.askyesno('CONFIRMAR INSTALAÇÃO',
            'O JOGO PRECISA ESTAR FECHADO.\n\n'
            'A tradução atual será gerada e instalada em:\n'+str(game_data)+'\n\n'
            'Os arquivos anteriores e originais limpos terão backup automático em:\n'+str(backup)+'\n\n'
            'O arquivo japonês original não será modificado.\n\n'
            'Todos os arquivos serão conferidos antes e depois. Confirmar instalação?'):
            return
        try:
            report=core.install_translation(base,game_data,backup,en,jp,translations,erasures)
            # A partir daqui data pode estar modificada; passar a usar originais preservados.
            base=Path(report['originais_preservados'])
            folder_var.set('Originais preservados para futuras revisões: '+str(base))
            messagebox.showinfo('INSTALAÇÃO CONCLUÍDA',
                'Arquivos instalados com hashes conferidos.\n\n'
                'Registros alterados: {}\n'.format(report['registros_modificados'])+
                'Avisos de revisão visual: {}\n\n'.format(len(report['avisos']))+
                'Agora abra o jogo para conferir o teste.\n\n'
                'Backups: '+str(backup)+'\n'
                'Guarde também seu CSV para continuar a tradução.')
        except Exception as exc:
            messagebox.showerror('INSTALAÇÃO NÃO CONCLUÍDA',str(exc))

    def restore_game():
        game=filedialog.askdirectory(title='Selecione o Nitroplus Blasterz (ou data) para RESTAURAR')
        if not game:return
        if not messagebox.askyesno('Restaurar arquivos anteriores?',
            'O JOGO PRECISA ESTAR FECHADO.\n\n'
            'Será restaurada a versão que estava instalada antes do ÚLTIMO teste do editor.\n'
            'O conteúdo atual precisa coincidir com o registrado na instalação.\n\n'
            'Local dos backups:\n'+str(backup_directory)+'\n\nContinuar?'):
            return
        try:
            info=core.restore_last_install(game,backup_directory)
            messagebox.showinfo('VERSÃO ANTERIOR RESTAURADA',
                'Os três arquivos anteriores foram recuperados e conferidos.\n\nPasta: '+info['jogo'])
        except Exception as exc:
            messagebox.showerror('Restauração interrompida',str(exc))

    # Mapeamento CONFERIDO em ambas as BMF modificadas, com a tradução 1.0.
    # Não é uma promessa de suporte a TODOS os caracteres da língua portuguesa.
    # S1/S2: adaptações ã õ ç á ú í ó + glifos próprios é e ō.
    # S3: adaptações ã õ ç + glifos próprios à á é í ò ó ù û ē ě ǔ.
    ACCENTS_S12=frozenset('ãõçáúíóéō')
    ACCENTS_S3=frozenset('ãõçàáéíòóùûēěǔ')

    def unsupported_accents(value, section):
        """Caracteres fora do conjunto de glifos/adaptações CONFERIDOS."""
        allowed=ACCENTS_S12 if section in (1,2) else ACCENTS_S3
        found=set()
        for char in value:
            if char in allowed or char in '\n\r\t':
                continue
            cat=unicodedata.category(char)
            if (unicodedata.combining(char) or cat.startswith('M') or
                (ord(char)>127 and (cat.startswith('L') or cat.startswith('P')))):
                found.add(char)
        return sorted(found)

    def measure_preview(value):
        """Estimativa ponderada da ocupação, calibrada por 30 W/linha.

        Não afirma o limite real para nenhuma frase. O jogo usa outras
        métricas e regras de quebra. Contagem é exibida como aproximação.
        """
        if not value:
            return 1, 0, 0.0
        font=vn_font
        # Usar a largura de 30 W, conservadora, mesmo que o painel seja maior.
        # A estimativa ainda não substitui a quebra e a fonte reais do jogo.
        width=max(1,font.measure('W'*30),font.measure('Teste'*12))
        line_count=0
        maxfill=0.0
        for raw_line in value.split('\n'):
            # Tk wrap='word' respeita palavras; simulação base width in pixels.
            if not raw_line:
                line_count+=1
                continue
            words=raw_line.split(' ')
            used=0
            for ix,word in enumerate(words):
                group=(' ' if ix else '')+word
                w=font.measure(group)
                if used and used+w>width:
                    line_count+=1
                    maxfill=max(maxfill,used/width)
                    used=font.measure(word)
                else:
                    used+=w
                if used>width:
                    # palavras longas podem ser quebradas por caractere
                    while used>width:
                        line_count+=1
                        maxfill=max(maxfill,1.0)
                        used-=width
            line_count+=1
            maxfill=max(maxfill,used/width)
        return line_count,len(value),maxfill

    def update_counter(event=None):
        if current is None:
            char_count_var.set('Selecione um registro')
            vn_estimate_var.set('Prévia de VN: esperando texto')
            glyph_alert_var.set('Caracteres fora do conjunto reconhecido aparecerão aqui')
            vn_outer.configure(highlightbackground='#7783b0')
            return
        value=ptbox.get('1.0','end-1c')
        try:
            game_units=len(core.human_to_game(value,current[0]).encode('utf-16le'))//2
        except UnicodeError:
            game_units=-1
        lines=value.split('\n')
        original=en[current[0]-1].texts[current[1]]
        char_count_var.set('PT: {} caracteres | {} linhas manuais | {} unidades TDF | EN: {} caracteres'.format(len(value),len(lines),game_units,len(original)))
        vlines,n,maxfill=measure_preview(value)
        if current[0]==3:
            vn_estimate_var.set('S3 — MENU: edição livre, sem limite visual de 3 linhas; confira o tamanho no jogo.')
            estimate_label.configure(foreground='#475569')
            vn_outer.configure(highlightbackground='#7783b0')
        elif not vn_fits(value):
            vn_estimate_var.set('S1/S2: TEXTO ACIMA DE 3 LINHAS (anterior salvo). Reduza para caber.')
            estimate_label.configure(foreground='#b91c1c')
            vn_outer.configure(highlightbackground='#dc2626')
        elif vn_displaylines()==3:
            vn_estimate_var.set('S1/S2: 3/3 linhas ocupadas • excesso de digitação será recusado')
            estimate_label.configure(foreground='#92400e')
            vn_outer.configure(highlightbackground='#d97706')
        else:
            vn_estimate_var.set('S1/S2: {}/3 linhas visíveis usadas • limite ativo'.format(vn_displaylines()))
            estimate_label.configure(foreground='#047857')
            vn_outer.configure(highlightbackground='#7783b0')
        if current[0] in (1,2) and vn_guard.get('notice'):
            vn_estimate_var.set(vn_guard['notice'])
            estimate_label.configure(foreground='#b91c1c')
            vn_outer.configure(highlightbackground='#dc2626')
        bad=unsupported_accents(value,current[0])
        if bad:
            glyph_alert_var.set('SEM SUPORTE CONFIRMADO NESTA SEÇÃO: {} — pode não aparecer no jogo'.format(' '.join(bad[:35]) + (' …' if len(bad)>35 else '')))
            glyph_label.configure(foreground='#b91c1c')
        else:
            glyph_alert_var.set('Caracteres desta fala: sem acentos incompatíveis detectados.')
            glyph_label.configure(foreground='#047857')
        # Caracteres suspeitos recebem um fundo discreto dentro do editor.
        ptbox.tag_remove('glyph_unsupported','1.0','end')
        for i,c in enumerate(value):
            if c in bad:
                ptbox.tag_add('glyph_unsupported','1.0 + {} chars'.format(i),'1.0 + {} chars'.format(i+1))

    def copy_context():
        if current is None:return
        try:save_current()
        except Exception as exc:return messagebox.showerror('Erro',str(exc))
        s,i=current
        payload='JP:\n{}\n\nEN:\n{}\n\nPT:\n{}'.format(jp[s-1].texts[i],en[s-1].texts[i],translations.get(current,'(manter inglês)' if current not in erasures else '(APAGAR)'))
        root.clipboard_clear();root.clipboard_append(payload)
        set_note('JP + EN + PT copiados: S{}_{:04d}.'.format(s,i))

    def clear_pt():
        if current is None:return
        vn_assign('');erase_var.set(False)
        try:save_current()
        except Exception as exc:return messagebox.showerror('Erro',str(exc))
        refresh_rows(current)

    def erase_toggle():
        if erase_var.get():
            if messagebox.askyesno('Apagar de verdade?','Isto gerará um registro de texto VAZIO no jogo.\nÉ diferente de não traduzir.\n\nConfirmar?'):
                vn_assign('')
            else:
                erase_var.set(False)

    for label,fn in [('Abrir tradução / projeto',import_any),('Abrir originais',choose_game),('Abrir instalada (pasta/arquivos)',import_installed),('Salvar CSV',export_csv),('Salvar projeto',export_project),('Validar',validate),('Gerar TDF + fontes',build)]:
        ttk.Button(toolbar,text=label,command=fn).pack(side='left',padx=(0,7))

    installation_row=ttk.Frame(root)
    installation_row.pack(fill='x',padx=14,pady=(0,7))
    ttk.Button(installation_row,text='Instalar tradução no jogo (com backup)',command=install_in_game).pack(side='left',padx=(0,8))
    ttk.Button(installation_row,text='Restaurar versão anterior',command=restore_game).pack(side='left',padx=(0,8))
    ttk.Label(installation_row,text='Backups privados: '+str(backup_directory)).pack(side='left')

    search_frame=ttk.Frame(root)
    search_frame.pack(fill='x',padx=14,pady=4)
    ttk.Label(search_frame,text='Busca por ID/texto:').pack(side='left')
    search=ttk.Entry(search_frame,textvariable=query_var,width=37)
    search.pack(side='left',padx=(6,15),fill='x',expand=True)
    ttk.Label(search_frame,text='Seção:').pack(side='left')
    ttk.Combobox(search_frame,textvariable=section_var,values=['Todas','S1','S2','S3'],state='readonly',width=8).pack(side='left',padx=(5,12))
    ttk.Label(search_frame,text='Estado:').pack(side='left')
    ttk.Combobox(search_frame,textvariable=status_filter_var,values=['Todos','Com tradução','Sem tradução','Apagar'],state='readonly',width=15).pack(side='left',padx=(5,0))
    query_var.trace_add('write',on_search)
    section_var.trace_add('write',on_search)
    status_filter_var.trace_add('write',on_search)
    root.bind('<Control-f>',lambda e:search.focus_set())

    splitter=ttk.Panedwindow(root,orient='horizontal')
    splitter.pack(fill='both',expand=True,padx=14,pady=(6,4))
    left=ttk.Frame(splitter)
    right_host=ttk.Frame(splitter)
    splitter.add(left,weight=1)
    splitter.add(right_host,weight=2)
    # Toda a coluna de edição pode ser rolada em telas de 720p, sem ocultar
    # salvar/instalar ou os controles de revisão.
    right_canvas=tk.Canvas(right_host,width=580,highlightthickness=0,borderwidth=0)
    right_scroll=ttk.Scrollbar(right_host,orient='vertical',command=right_canvas.yview)
    right_canvas.configure(yscrollcommand=right_scroll.set)
    right_scroll.pack(side='right',fill='y')
    right_canvas.pack(side='left',fill='both',expand=True)
    right=ttk.Frame(right_canvas)
    right_window=right_canvas.create_window((0,0),window=right,anchor='nw')
    def resize_editor_area(event=None):
        right_canvas.configure(scrollregion=right_canvas.bbox('all'))
    def resize_editor_width(event):
        right_canvas.itemconfigure(right_window,width=event.width)
    right.bind('<Configure>',resize_editor_area)
    right_canvas.bind('<Configure>',resize_editor_width)
    tree=ttk.Treeview(left,columns=('ID','Status','EN'),show='headings',selectmode='browse')
    tree.heading('ID',text='ID');tree.heading('Status',text='Estado');tree.heading('EN',text='Inglês (prévia)')
    tree.column('ID',width=100,stretch=False);tree.column('Status',width=85,stretch=False)
    tree.column('EN',width=160,stretch=True)
    sc=ttk.Scrollbar(left,orient='vertical',command=tree.yview);tree.configure(yscrollcommand=sc.set)
    sc.pack(side='right',fill='y');tree.pack(side='left',fill='both',expand=True)
    tree.bind('<<TreeviewSelect>>',on_select)

    id_label=ttk.Label(right,text='Escolha uma entrada para começar.',font=('Segoe UI',12,'bold'))
    id_label.pack(anchor='w',pady=(0,5))

    def textbox(frame,height,readonly=False):
        f=ttk.Frame(frame)
        f.pack(fill='both',expand=1,pady=(1,5))
        txt=tk.Text(f,height=height,font=('Segoe UI',11),wrap='word',undo=True)
        sb=ttk.Scrollbar(f,orient='vertical',command=txt.yview);txt.configure(yscrollcommand=sb.set)
        sb.pack(side='right',fill='y');txt.pack(fill='both',expand=1,side='left')
        if readonly:txt.configure(state='disabled')
        return txt

    ttk.Label(right,textvariable=jp_caption_var).pack(anchor='w')
    jpbox=textbox(right,4,True)
    ttk.Label(right,text='Inglês original (somente leitura)').pack(anchor='w')
    enbox=textbox(right,4,True)
    ttk.Label(right,text='PT-BR — EDITE AQUI (S1/S2: VN; S3: menu livre; vazio = manter inglês)').pack(anchor='w')
    # Caixa de texto realmente editável inspirada no quadro VN original.
    # Não incorpora imagens/texturas do jogo. O nome ??? é somente ilustrativo;
    # a fonte Segoe UI é uma aproximação e não muda o sistema de glifos do TDF.
    vn_bg='#0b0c16'
    vn_font=tkfont.Font(root,family='Segoe UI',size=11)
    vn_linespace=vn_font.metrics('linespace')
    # A caixa tem largura PREDEFINIDA, não se expande para preencher a coluna.
    # A largura foi aproximada dos testes: 30 W ou 12 'Teste' por linha.
    # Com a fonte desta prévia, ambas as amostras cabem nas 3 linhas.
    vn_reference_width=max(vn_font.measure('W'*30),vn_font.measure('Teste'*12))
    vn_arrow_width=27
    vn_entry_width=vn_reference_width+2
    vn_outer_width=vn_entry_width+vn_arrow_width+24
    vn_outer=tk.Frame(right,bg=vn_bg,
                      highlightbackground='#7783b0',highlightthickness=2)
    vn_outer.pack(anchor='w',pady=(2,4))
    vn_header=tk.Frame(vn_outer,bg=vn_bg)
    vn_header.pack(fill='x',padx=(10,7),pady=(5,0))
    vn_speaker_label=tk.Label(vn_header,text='???',bg=vn_bg,fg='#ffffff',
             font=('Consolas',16,'bold'),anchor='w')
    vn_speaker_label.pack(side='left')
    vn_rule=tk.Frame(vn_outer,bg='#f6f6fa',height=2)
    vn_rule.pack(fill='x',padx=(10,7),pady=(2,0))

    vn_body=tk.Frame(vn_outer,bg=vn_bg)
    vn_body.pack(anchor='w',padx=(10,6),pady=(4,7))
    vn_edit_holder=tk.Frame(vn_body,bg=vn_bg,width=vn_entry_width,
                            height=vn_linespace*3+8)
    vn_edit_holder.pack(side='left')
    vn_edit_holder.pack_propagate(False)
    ptbox=tk.Text(vn_edit_holder,height=3,font=vn_font,wrap='word',undo=True,
                  bg=vn_bg,fg='#f8fafc',insertbackground='#ffffff',
                  selectbackground='#475569',relief='flat',borderwidth=0,
                  highlightthickness=0,padx=1,pady=2,spacing1=0,spacing3=0)
    ptbox.pack(side='left',fill='both',expand=True)
    vn_scroll=tk.Scrollbar(vn_edit_holder,command=ptbox.yview)
    ptbox.configure(yscrollcommand=vn_scroll.set)
    ptbox.tag_configure('glyph_unsupported',background='#6b283a',foreground='#fff7ed')
    # As setas ficam imediatamente APÓS a área máxima de digitação,
    # não coladas na lateral direita da janela (nem dentro do conteúdo salvo).
    vn_arrows=tk.Canvas(vn_body,width=vn_arrow_width,height=vn_linespace*3+8,
                        bg=vn_bg,highlightthickness=0,borderwidth=0)
    vn_arrows.pack(side='left',padx=(0,0))
    def redraw_vn_arrows(event=None):
        vn_arrows.delete('all')
        w=max(23,vn_arrows.winfo_width())
        h=max(58,vn_arrows.winfo_height())
        for index in range(3):
            cy=h-49+index*18
            cx=w/2
            vn_arrows.create_polygon(cx-8,cy-4,cx+8,cy-4,cx,cy+5,
                                     fill='#ff1825',outline='')
    vn_arrows.bind('<Configure>',redraw_vn_arrows)
    redraw_vn_arrows()

    def set_section_edit_mode(section):
        """S1/S2: moldura limitada; S3: campo de menu maior e sem limite."""
        if section == 3:
            vn_speaker_label.configure(text='S3 — MENU (sem limite de linhas)',font=('Segoe UI',11,'bold'))
            vn_arrows.pack_forget()
            ptbox.pack_forget()
            vn_scroll.pack(side='right',fill='y')
            ptbox.pack(side='left',fill='both',expand=True)
            vn_outer.pack_configure(fill='x',anchor='w')
            vn_body.pack_configure(fill='x',anchor='w')
            vn_edit_holder.configure(width=vn_reference_width+100,height=vn_linespace*7+16)
            vn_edit_holder.pack_configure(fill='x',expand=True)
            ptbox.configure(height=7)
        else:
            vn_speaker_label.configure(text='???',font=('Consolas',16,'bold'))
            ptbox.pack_forget()
            vn_scroll.pack_forget()
            ptbox.pack(side='left',fill='both',expand=True)
            vn_outer.pack_configure(fill='none',anchor='w')
            vn_body.pack_configure(fill='none',anchor='w')
            vn_edit_holder.configure(width=vn_entry_width,height=vn_linespace*3+8)
            vn_edit_holder.pack_configure(fill='none',expand=False)
            ptbox.configure(height=3)
            vn_arrows.pack(side='left',padx=(0,0))
            redraw_vn_arrows()

    # Bloqueia inserções/colagens que passem de 3 linhas VISÍVEIS nesta caixa.
    # Textos antigos acima desse limite são mantidos intactos ao abrir um CSV:
    # o usuário pode diminuí-los, mas não aumentar sua ocupação.
    # NADA é truncado no carregamento nem na exportação.
    vn_guard={'active':True,'accepted':'','loaded_oversize':False,'notice':''}

    def vn_displaylines():
        '''Conta linhas com a quebra do próprio widget, incluindo linhas vazias.'''
        root.update_idletasks()
        n=ptbox.count('1.0','end','displaylines')
        return n[0] if n else 1

    def vn_fits(value=None):
        value=get_widget(ptbox) if value is None else value
        if current is not None and current[0]==3:
            return True  # Menu não tem limite de moldura; continua sujeito à validação TDF.
        if value.count('\n') > 2:
            return False
        return vn_displaylines() <= 3

    def vn_assign(value, *, allow_existing=False):
        # Carregamento de traduções antigas pode conter textos maiores que o
        # espaço confortável; permitir leitura sem excluir nenhum caractere.
        vn_guard['active']=False
        try:
            ptbox.delete('1.0','end')
            ptbox.insert('1.0',value)
            ptbox.edit_modified(False)
            ptbox.edit_reset()  # evita desfazer e recuperar texto de outro registro
        finally:
            vn_guard['active']=True
        vn_guard['accepted']=value
        vn_guard['loaded_oversize']=not vn_fits(value)
        vn_guard['notice']=''
        update_counter()
        return not vn_guard['loaded_oversize']

    def vn_check_modify(event=None):
        if not ptbox.edit_modified():
            return
        ptbox.edit_modified(False)
        if not vn_guard['active']:
            return
        candidate=get_widget(ptbox)
        previous=vn_guard['accepted']
        if current is not None and current[0]==3:
            vn_guard.update(accepted=candidate,loaded_oversize=False,notice='')
            update_counter()
            return
        if candidate == previous:
            update_counter()
            return
        fits=vn_fits(candidate)
        # Em legado grande, permitir só reduções (ou texto que passe a caber).
        if fits or (vn_guard['loaded_oversize'] and len(candidate)<len(previous)):
            vn_guard['accepted']=candidate
            vn_guard['loaded_oversize']=not fits
            vn_guard['notice']=''
            update_counter()
            return
        # Rejeitar a edição INTEIRA, sem aceitar o excesso ou cortar texto.
        # Restaura a seleção aproximada e a posição do cursor.
        index=ptbox.index('insert')
        vn_guard['active']=False
        try:
            ptbox.delete('1.0','end')
            ptbox.insert('1.0',previous)
            try:ptbox.mark_set('insert',index)
            except tk.TclError:ptbox.mark_set('insert','end-1c')
            ptbox.edit_modified(False)
            ptbox.edit_separator()
        finally:
            vn_guard['active']=True
        vn_guard['notice']='LIMITE: só 3 linhas visíveis. A última digitação/colagem foi recusada.'
        update_counter()

    ptbox.bind('<<Modified>>',vn_check_modify)
    ptbox.edit_modified(False)
    # Modo do editor é intencionalmente estrito; alterar o core não é necessário.
    # Avisos fora da moldura, para manter a área de fala limpa e legível.
    estimate_label=tk.Label(right,textvariable=vn_estimate_var,fg='#475569',
                            font=('Segoe UI',10),anchor='w')
    estimate_label.pack(fill='x',pady=(1,0))
    glyph_label=tk.Label(right,textvariable=glyph_alert_var,fg='#9a6700',
                         font=('Segoe UI',10),anchor='w')
    glyph_label.pack(fill='x',pady=(0,3))
    ttk.Label(right,textvariable=char_count_var).pack(anchor='w',pady=(0,3))
    ttk.Label(right,text='Acentos disponíveis no editor — S1/S2: ã õ ç á é í ó ú ō',
              foreground='#666666',wraplength=580).pack(anchor='w')
    ttk.Label(right,text='S3: ã õ ç à á é í ò ó ù û ē ě ǔ',
              foreground='#666666',wraplength=580).pack(anchor='w',pady=(0,4))
    ttk.Label(right,text='S1/S2: limite visual de 3 linhas estimadas. S3: menus sem bloqueio de espaço.',
              foreground='#555555').pack(anchor='w',pady=(0,7))

    small=ttk.Frame(right)
    small.pack(fill='x',pady=(0,6))
    ttk.Checkbutton(small,text='APAGAR explicitamente o texto no jogo',variable=erase_var,command=erase_toggle).pack(side='left')
    ttk.Button(small,text='Limpar PT (manter EN)',command=clear_pt).pack(side='right')
    ttk.Label(right,text='Observações do tradutor').pack(anchor='w')
    note_box=textbox(right,2)
    ttk.Button(right,text='Copiar JP + EN + PT',command=copy_context).pack(anchor='w',pady=(2,5))

    footer=ttk.Frame(root)
    footer.pack(fill='x',padx=14,pady=(3,12))
    ttk.Label(footer,textvariable=stats_var,wraplength=1100).pack(anchor='w')
    ttk.Label(footer,text='CSV: UTF-8 BOM e separador ;. O editor usa os glifos e as conversões existentes do jogo, sem alterar as fontes.',foreground='#555555').pack(anchor='w')

    def wheel_right(event):
        """Roda do mouse no painel direito, inclusive sobre rótulos e moldura."""
        if current is not None and current[0]==3 and event.widget == ptbox:
            lo,hi=ptbox.yview()
            direction=-1 if (getattr(event,'num',None)==4 or getattr(event,'delta',0)>0) else 1
            if direction<0 and lo>0 or direction>0 and hi<1:
                ptbox.yview_scroll(direction*3,'units')
                return 'break'
        delta=getattr(event,'delta',0)
        if delta:
            steps=-max(1,abs(int(delta))//120) if delta>0 else max(1,abs(int(delta))//120)
        else:
            steps=-1 if getattr(event,'num',None)==4 else 1
        right_canvas.yview_scroll(steps*3,'units')
        return 'break'

    def bind_right_wheel(widget):
        widget.bind('<MouseWheel>',wheel_right,add='+')
        widget.bind('<Button-4>',wheel_right,add='+')
        widget.bind('<Button-5>',wheel_right,add='+')
        for child in widget.winfo_children():
            bind_right_wheel(child)
    bind_right_wheel(right_host)

    def close():
        if en is not None and (translations or notes or erasures) and not messagebox.askyesno('Sair?','Salve seu CSV ou projeto .ntproj antes de fechar!\nFechar o editor agora?'):
            return
        root.destroy()
    root.protocol('WM_DELETE_WINDOW',close)
    root.mainloop()


if __name__=='__main__':
    try:
        cli()
    except Exception as exc:
        print('ERRO:',type(exc).__name__,str(exc),file=sys.stderr)
        sys.exit(1)
