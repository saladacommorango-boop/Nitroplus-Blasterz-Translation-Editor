"""Projetos portáteis e reimportação TDF do Nitroplus Editor V1.9.

Nunca executa conteúdo de ZIP e nunca inclui EN/JP/fontes proprietárias
no arquivo de projeto. Os originais legítimos devem estar disponíveis na
máquina do usuário para leitura JP/EN e reconstrução do TDF.
"""
import json
import os
from pathlib import Path
import tempfile
import zipfile

import nitro_core as core

PROJECT_MEMBER = 'PROJETO_NITROPLUS_V1.json'
PROJECT_FORMAT = 'nitroplus-editor-project'
PROJECT_VERSION = 1
MAX_PROJECT_SIZE = 4 * 1024 * 1024


def _key_to_id(k):
    return 'S{}_{:04d}'.format(*k)


def _id_to_key(k):
    import re
    if not isinstance(k, str) or not re.fullmatch(r'S[123]_\d{4}',k):
        raise ValueError('ID de projeto inválido: '+str(k)[:80])
    sec,index = int(k[1]),int(k[3:])
    if index >= core.EXPECTED_COUNTS[sec-1]:
        raise ValueError('Índice de projeto fora da tabela: '+k)
    return sec,index


def make_project_bytes(en, jp, translations, notes=None, erasures=None):
    notes = notes or {}
    erasures = erasures or set()
    # Validar antes de exportar. Isso confirma que todos os campos são válidos,
    # inclusive traduções antigas acima do limite visual estimado.
    core.make_build(en, translations, erasures)
    if set(translations) & set(erasures):
        raise ValueError('Um ID não pode estar traduzido e marcado para APAGAR.')
    for k,v in notes.items():
        _id_to_key(_key_to_id(k))
        if not isinstance(v,str) or len(v)>100000:
            raise ValueError('Observação inválida')
    payload={
        'formato':PROJECT_FORMAT,
        'versao':PROJECT_VERSION,
        'jogo':'Nitroplus Blasterz (Steam EN/JP, estrutura verificada)',
        'originais_sha256':{core.EN_NAME:core.KNOWN_SHA[core.EN_NAME],
                            core.JP_NAME:core.KNOWN_SHA[core.JP_NAME]},
        'traducoes':{_key_to_id(k):translations[k] for k in sorted(translations)},
        'observacoes':{_key_to_id(k):notes[k] for k in sorted(notes)},
        'apagar':[_key_to_id(k) for k in sorted(erasures)],
        'aviso':'PROJETO DE TRADUÇÃO. Não contém arquivos originais EN/JP, fontes ou instalador.'
    }
    raw=json.dumps(payload,ensure_ascii=False,separators=(',',':'),sort_keys=True).encode('utf-8')
    if len(raw)>MAX_PROJECT_SIZE:
        raise ValueError('Projeto maior que o tamanho seguro')
    return raw


def save_project(path,en,jp,translations,notes=None,erasures=None):
    path=Path(path)
    if path.suffix.lower()!='.ntproj':
        raise ValueError('O arquivo de projeto precisa terminar em .ntproj')
    if not path.parent.is_dir():
        raise FileNotFoundError('A pasta do projeto não existe')
    raw=make_project_bytes(en,jp,translations,notes,erasures)
    temp_name=None
    # Salvar de modo atômico, preservando o anterior se existir.
    try:
        with tempfile.NamedTemporaryFile(dir=path.parent,prefix='.nitro_proj_',suffix='.tmp',delete=False) as out:
            temp_name=out.name
        with zipfile.ZipFile(temp_name,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            z.writestr(PROJECT_MEMBER,raw)
        read_project(temp_name,en,jp)
        backup=None
        if path.exists():
            for i in range(1,10000):
                b=path.with_name(path.name+'.backup_{:04d}'.format(i))
                if not b.exists():
                    import shutil
                    shutil.copy2(path,b)
                    backup=b
                    break
            if backup is None:
                raise IOError('Número excessivo de backups')
        os.replace(temp_name,path)
        temp_name=None
        return backup
    finally:
        if temp_name is not None:
            Path(temp_name).unlink(missing_ok=True)


def read_project(path,en,jp):
    if en is None or jp is None:
        raise ValueError('Originais verificados EN/JP necessários')
    with zipfile.ZipFile(path) as z:
        files=z.infolist()
        if len(files)!=1 or files[0].filename!=PROJECT_MEMBER:
            raise ValueError('Projeto não contém um único JSON válido do editor')
        if files[0].file_size>MAX_PROJECT_SIZE:
            raise ValueError('Arquivo de projeto acima do limite seguro')
        raw=z.read(files[0])
    if len(raw)>MAX_PROJECT_SIZE:
        raise ValueError('Arquivo de projeto muito grande')
    data=json.loads(raw.decode('utf-8'))
    if not isinstance(data,dict) or data.get('formato')!=PROJECT_FORMAT or data.get('versao')!=PROJECT_VERSION:
        raise ValueError('Formato/versão de projeto incompatível')
    expected={core.EN_NAME:core.KNOWN_SHA[core.EN_NAME],core.JP_NAME:core.KNOWN_SHA[core.JP_NAME]}
    if data.get('originais_sha256') != expected:
        raise ValueError('Projeto foi criado para outra versão EN/JP')
    if not isinstance(data.get('traducoes'),dict) or not isinstance(data.get('observacoes'),dict) or not isinstance(data.get('apagar'),list):
        raise ValueError('Campos do projeto incompletos')
    if len(data['traducoes'])>sum(core.EXPECTED_COUNTS) or len(data['apagar'])>sum(core.EXPECTED_COUNTS):
        raise ValueError('Quantidade de registros incompatível')
    translations={_id_to_key(k):v for k,v in data['traducoes'].items()}
    notes={_id_to_key(k):v for k,v in data['observacoes'].items()}
    erasures={_id_to_key(k) for k in data['apagar']}
    if len(erasures)!=len(data['apagar']):
        raise ValueError('ID APAGAR duplicado')
    if set(translations) & erasures:
        raise ValueError('IDs de tradução e APAGAR sobrepostos')
    for k,v in translations.items():
        if not isinstance(v,str) or not v:
            raise ValueError('Tradução vazia inválida em '+_key_to_id(k))
        core.check_translation(v,k)
    for k,v in notes.items():
        if not isinstance(v,str) or len(v)>100000:
            raise ValueError('Observação inválida em '+_key_to_id(k))
    core.make_build(en,translations,erasures)
    return translations,notes,erasures


def read_generated_tdf(path,en):
    """Importa um arquivo TDF gerado ou modificado, SEM aceitar mudanças na estrutura.

    O usuário pode selecionar o arquivo de saída sem extensão do editor,
    ou um ZIP só com o TDF, desde que ele tenha o nome exato conhecido.
    """
    path=Path(path)
    if zipfile.is_zipfile(path):
        with zipfile.ZipFile(path) as z:
            entries=[f for f in z.infolist() if f.filename==core.EN_NAME and not f.is_dir()]
            if len(entries)!=1:
                raise ValueError('O ZIP não contém exatamente um arquivo TDF reconhecido')
            if entries[0].file_size>core.MAX_FILE_SIZE:
                raise ValueError('TDF compactado muito grande')
            data=z.read(entries[0])
    else:
        if path.stat().st_size>core.MAX_FILE_SIZE:
            raise ValueError('TDF acima do tamanho permitido')
        data=path.read_bytes()
    return read_generated_tdf_bytes(data,en)


def read_generated_tdf_bytes(data,en):
    """Mesmas verificações byte-a-byte para arquivo, pasta ou ZIP instalado."""
    parsed=core.parse_tdf(data)
    if any(sec.markers!=orig.markers for sec,orig in zip(parsed,en)):
        raise ValueError('Este TDF alterou marcadores/agrupamentos. Importação insegura.')
    translations={};erasures=set()
    for sec,(original,changed) in enumerate(zip(en,parsed),1):
        for idx,(old,new) in enumerate(zip(original.texts,changed.texts)):
            if new!=old:
                key=(sec,idx)
                if new=='':
                    erasures.add(key)
                else:
                    human=core.game_to_human(new,sec)
                    core.check_translation(human,key)
                    translations[key]=human
    # Proteção contra perda silenciosa: se o editor não reproduzir EXATAMENTE
    # os bytes do TDF que foi lido, a importação é recusada.
    rebuilt,_,_=core.make_build(en,translations,erasures)
    if rebuilt!=data:
        raise ValueError('TDF não pode ser reconstruído exatamente; nenhuma entrada importada.')
    return translations,{},erasures
