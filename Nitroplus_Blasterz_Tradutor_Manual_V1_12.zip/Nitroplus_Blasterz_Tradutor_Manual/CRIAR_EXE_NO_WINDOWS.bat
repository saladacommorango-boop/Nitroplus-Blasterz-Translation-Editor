@echo off
setlocal
cd /d "%~dp0"
echo Requer PyInstaller instalado no seu Python Windows.
echo Instalacao opcional: py -3 -m pip install pyinstaller
echo Nenhum arquivo do jogo sera incluido no executavel.
py -3 -m PyInstaller --onefile --windowed --clean --noconfirm --name "Nitroplus_Editor" "Nitroplus_Editor.py"
if errorlevel 1 (
 echo Falha ao gerar EXE. Veja os erros acima.
 pause
 exit /b 1
)
echo EXE criado na pasta dist.
pause
