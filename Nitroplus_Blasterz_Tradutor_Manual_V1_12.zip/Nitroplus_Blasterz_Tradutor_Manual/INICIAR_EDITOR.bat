@echo off
setlocal
cd /d "%~dp0"
py -3 "Nitroplus_Editor.py"
if errorlevel 1 (
 echo.
 echo Erro ao abrir com py -3. Tentando python diretamente...
 python "Nitroplus_Editor.py"
)
if errorlevel 1 pause
