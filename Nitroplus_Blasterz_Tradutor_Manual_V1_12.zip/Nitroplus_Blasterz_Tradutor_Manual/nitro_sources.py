"""Backups verificados: três originais obrigatórios, JP opcional.

Leia pasta de backup (preferencial), ZIP de backup ou seleção individual.
Somente arquivos da versão Steam EN conhecida entram no cache privado.
Nunca execute ZIP nem escreva na pasta do jogo.
"""
from pathlib import Path
import os
import re
import tempfile
import zipfile

import nitro_core as core

REQUIRED_NAMES = (core.EN_NAME, core.FONT03_NAME, core.FONT04_NAME)
SOURCE_NAMES = REQUIRED_NAMES + (core.JP_NAME,)
CACHE_SUBDIR = 'Nitroplus_Editor_Originais_Verificados'


def cache_location():
    return Path.home() / CACHE_SUBDIR


def _normalize_name(filename):
    basename=Path(str(filename).replace('\\','/')).name
    for name in SOURCE_NAMES:
        if re.fullmatch(re.escape(name) + r'(?:\s*\(\d{1,5}\))?',basename,re.I):
            return name
    return None


def _validated_files(payloads):
    if not set(REQUIRED_NAMES).issubset(payloads):
        missing=[name for name in REQUIRED_NAMES if name not in payloads]
        raise ValueError('Backup incompleto: faltam os originais ' + ', '.join(missing))
    if set(payloads) - set(SOURCE_NAMES):
        raise ValueError('Backup inclui arquivo com nome não reconhecido')
    for name,raw in payloads.items():
        if len(raw)>core.MAX_FILE_SIZE or core.sha(raw)!=core.KNOWN_SHA[name]:
            raise ValueError('Arquivo não é original Steam ou está alterado: ' + name + '\n'
                             'Não use o backup dos arquivos JÁ TRADUZIDOS como referência EN.')


def _cache_verified_payloads(payloads):
    _validated_files(payloads)
    root=cache_location()
    if root.exists() and (root.is_symlink() or not root.is_dir()):
        raise ValueError('Pasta privada de originais é inválida: '+str(root))
    root.mkdir(parents=True,exist_ok=True)
    for name in SOURCE_NAMES:
        if name not in payloads: continue
        target=root/name
        if target.is_symlink():
            raise ValueError('Link simbólico não aceito: '+str(target))
        if target.exists():
            core.read_known(target,name)
            continue
        tmp=None
        try:
            with tempfile.NamedTemporaryFile(dir=root,prefix='.nitro_original_',delete=False) as fp:
                tmp=fp.name
                fp.write(payloads[name]);fp.flush();os.fsync(fp.fileno())
            if core.sha(Path(tmp).read_bytes())!=core.KNOWN_SHA[name]:
                raise ValueError('Original alterado durante gravação: '+name)
            os.replace(tmp,target)
            tmp=None
        finally:
            if tmp is not None: Path(tmp).unlink(missing_ok=True)
    return core.load_backup_sources(root)


def known_cached_sources():
    root=cache_location()
    if not root.is_dir() or root.is_symlink(): return None
    try:
        if any((root/name).is_symlink() for name in SOURCE_NAMES): return None
        return core.load_backup_sources(root)
    except (OSError,ValueError):
        return None


def import_backup_folder(folder):
    """A pasta pode ser o backup de três arquivos ou raiz contendo data/."""
    root=Path(folder)
    if root.is_symlink() or not root.is_dir():
        raise ValueError('Pasta de backup inválida')
    if (root/'data').is_dir(): root=root/'data'
    payloads={}
    for p in root.iterdir():
        if p.is_symlink() or not p.is_file(): continue
        name=_normalize_name(p.name)
        if not name:continue
        if name in payloads:
            raise ValueError('Backup com cópias ambíguas de '+name+'; deixe só um arquivo por nome.')
        if p.stat().st_size>core.MAX_FILE_SIZE:
            raise ValueError('Arquivo excessivo no backup: '+p.name)
        payloads[name]=p.read_bytes()
    return _cache_verified_payloads(payloads)


def import_backup_zip(zip_path):
    """Lê somente as 3 referências e, se presente, o JP; ZIP sem executar."""
    payloads={}
    with zipfile.ZipFile(zip_path) as z:
        if len(z.infolist())>10000:
            raise ValueError('ZIP com entradas demais')
        for member in z.infolist():
            if member.is_dir(): continue
            name=_normalize_name(member.filename)
            if name is None:continue
            if name in payloads:
                raise ValueError('ZIP com entradas duplicadas para '+name)
            if member.file_size>core.MAX_FILE_SIZE:
                raise ValueError('Arquivo acima do limite no ZIP: '+name)
            raw=z.read(member)
            if len(raw)!=member.file_size:
                raise ValueError('Arquivo ZIP incompleto: '+name)
            payloads[name]=raw
    return _cache_verified_payloads(payloads)


def import_migration_sources(zip_path):
    """Compatibilidade com ZIP antigo de migração; o mesmo leitor serve."""
    return import_backup_zip(zip_path)


def import_original_files(filepaths):
    payloads={}
    for selected in filepaths:
        p=Path(selected)
        if p.is_symlink() or not p.is_file():
            raise ValueError('Escolha arquivos originais regulares: '+str(p))
        name=_normalize_name(p.name)
        if not name: raise ValueError('Nome de arquivo não reconhecido: '+p.name)
        if name in payloads: raise ValueError('Originais duplicados para '+name)
        if p.stat().st_size>core.MAX_FILE_SIZE: raise ValueError('Original grande demais: '+p.name)
        payloads[name]=p.read_bytes()
    return _cache_verified_payloads(payloads)
