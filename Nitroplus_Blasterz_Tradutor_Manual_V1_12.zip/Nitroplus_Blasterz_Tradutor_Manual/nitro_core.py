#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Nitroplus Blasterz TDF/BMF - parser/editor seguro (stdlib Python 3.8+).

NENHUM arquivo do jogo é incluído. Requer arquivos legítimos do usuário.
O formato foi validado somente na versão Steam EN/JP identificada pelos SHA-256.
"""
import csv
import hashlib
import json
import os
from pathlib import Path
import re
import struct
import tempfile
import zipfile
import time
from dataclasses import dataclass
from typing import List, Tuple

EN_NAME = 'u00gShcmpphbia0v0iwiiuixdtsTtimwap'
JP_NAME = 'nfumbyij0nyrn0gzrnXuyl0Duyuhumn0nxz'
FONT03_NAME = 'axmetear0r0zf00dzf0erz0geyraafkrzf2'
FONT04_NAME = 'a0bhcc0t0ba0chgo0gtttbh0fih6tzbgvsc'
KNOWN_SHA = {
    EN_NAME: '97b163ce1203740537d24abe52686f6d670d7c65fb7c4b7158543e85b38a9ffa',
    JP_NAME: '7040c97224938eb4a9ee1d8bfe500eb972739964ccd49ba0b2c0a0a46686051e',
    FONT03_NAME: '459266cd31cf16f0bf69c2dc8d1591e7781f0b8d30063af987c32c30b0f75f0d',
    FONT04_NAME: '7fc7bd34b1adc9be6d4a7175f3d8e97b8be2482ca036fc1e2889a125019ad078',
}
VJ51_SHA = 'f50fc8165a0c69c2f625579b7ed702e918f2d70f4346ab3f4a6c588cb17df754'
VJ51_TDF_SHA = '26e5cd9cca88ddecefd55969a75544d35535fcb6dec7ce1911c56ac71ff38937'
FINAL_10_TDF_SHA = 'd0b23506c313240abd22e4560f22810127951ac81a73c6ed60492efac6c2d7d9'  # arquivo 1.0 verificado
EXPECTED_COUNTS = (1142, 1059, 1991)
COLS = ('id', 'secao', 'indice_0', 'grupo', 'ingles', 'japones', 'pt_br', 'acao', 'observacoes')
MAX_FILE_SIZE = 24 * 1024 * 1024
MAX_UNITS = 65535  # defesa conservadora, muito acima dos textos conhecidos


def sha(b):
    return hashlib.sha256(b).hexdigest()


def read_known(path, name=None):
    path = Path(path)
    if name is None:
        name = path.name
    if name not in KNOWN_SHA:
        raise ValueError('Nome de arquivo desconhecido: ' + name)
    if path.stat().st_size > MAX_FILE_SIZE:
        raise ValueError('Arquivo maior do que o limite seguro.\n' + str(path))
    raw = path.read_bytes()
    if sha(raw) != KNOWN_SHA[name]:
        raise ValueError('SHA-256 não corresponde ao original Steam conhecido: ' + name +
                         '\nHash encontrado: ' + sha(raw) +
                         '\nRestaure os originais ou use uma cópia legítima não modificada.')
    return raw


@dataclass
class Section:
    texts: List[str]
    markers: Tuple[int, ...]


def parse_tdf(blob):
    if len(blob) < 16 or len(blob) > MAX_FILE_SIZE:
        raise ValueError('TDF com tamanho inválido')
    n, *sizes = struct.unpack_from('<4I', blob, 0)
    if n != 3 or sum(sizes) + 16 != len(blob):
        raise ValueError('Cabeçalho TDF inválido')
    output = []
    section_start = 16
    for sec_i, size in enumerate(sizes):
        if size < 4:
            raise ValueError('Seção incompleta')
        sec = memoryview(blob)[section_start:section_start + size]
        count, = struct.unpack_from('<I', sec, 0)
        if count != EXPECTED_COUNTS[sec_i] or 4 + count * 4 > size:
            raise ValueError('Quantidade de textos/tabela inválida na S{}'.format(sec_i + 1))
        table = struct.unpack_from('<{}i'.format(count), sec, 4)
        pos = 4 + count * 4
        group_start = pos
        texts = []
        markers = []
        for idx, value in enumerate(table):
            if pos + 4 > size:
                raise ValueError('Texto truncado: S{} {}'.format(sec_i + 1, idx))
            units, = struct.unpack_from('<I', sec, pos)
            if units > MAX_UNITS:
                raise ValueError('Unidades UTF-16 excessivas: S{} {}'.format(sec_i + 1, idx))
            rec_len = 4 + units * 2
            if pos + rec_len > size:
                raise ValueError('Registro fora da seção')
            t = bytes(sec[pos + 4:pos + rec_len]).decode('utf-16le', 'strict')
            if value < 0:
                if value != rec_len - (pos - group_start):
                    raise ValueError('Índice negativo de grupo incompatível')
                markers.append(idx)
                group_start = pos
            elif value != rec_len:
                raise ValueError('Índice positivo incompatível')
            texts.append(t)
            pos += rec_len
        if pos != size:
            raise ValueError('Bytes residuais não interpretados')
        output.append(Section(texts, tuple(markers)))
        section_start += size
    return output


def serialize_tdf(sections):
    if len(sections) != 3:
        raise ValueError('Esperadas exatamente 3 seções')
    parts = []
    for sec_i, section in enumerate(sections):
        if len(section.texts) != EXPECTED_COUNTS[sec_i]:
            raise ValueError('Quantidade incorreta de registros')
        encoded = []
        for idx, t in enumerate(section.texts):
            if not isinstance(t, str) or '\x00' in t:
                # Arquivos de origem podem ter NUL? Não rejeitar origem aqui; na saída
                # recusamos NUL novos, mas o formato TDF pode legitimamente conter campos vazios.
                if not isinstance(t, str):
                    raise ValueError('Texto inválido S{} {}'.format(sec_i + 1, idx))
            b = t.encode('utf-16le', errors='strict')
            if len(b) // 2 > MAX_UNITS:
                raise ValueError('Campo excede limite de segurança')
            encoded.append(struct.pack('<I', len(b) // 2) + b)
        pos = 4 + 4 * len(encoded)
        group_start = pos
        markers = set(section.markers)
        if any(i < 0 or i >= len(encoded) for i in markers):
            raise ValueError('Marcadores fora da tabela')
        indexes = []
        for idx, rec in enumerate(encoded):
            value = len(rec)
            if idx in markers:
                value = len(rec) - (pos - group_start)
                if value >= 0:
                    raise ValueError('Marcador de grupo passou a não-negativo em S{} {}'.format(sec_i + 1, idx))
                group_start = pos
            if not -0x80000000 <= value <= 0x7fffffff:
                raise ValueError('Tamanho de índice inválido')
            indexes.append(value)
            pos += len(rec)
        part = struct.pack('<I', len(encoded)) + struct.pack('<{}i'.format(len(indexes)), *indexes) + b''.join(encoded)
        parts.append(part)
    result = struct.pack('<4I', 3, *(len(p) for p in parts)) + b''.join(parts)
    if not same_structure(parse_tdf(result), sections):
        raise AssertionError('Arquivo gerado não passou na validação de estrutura')
    return result


def same_structure(a, b):
    return (len(a) == len(b) and all(x.markers == y.markers and x.texts == y.texts for x, y in zip(a, b)))


def load_sources(data_dir):
    root = Path(data_dir)
    if (root / 'data' / EN_NAME).is_file():
        root = root / 'data'
    en_blob = read_known(root / EN_NAME, EN_NAME)
    jp_blob = read_known(root / JP_NAME, JP_NAME)
    en = parse_tdf(en_blob)
    jp = parse_tdf(jp_blob)
    if any(a.markers != b.markers for a, b in zip(en, jp)):
        raise ValueError('Marcadores EN/JP divergem')
    if serialize_tdf(en) != en_blob or serialize_tdf(jp) != jp_blob:
        raise ValueError('A reconstrução exata do original falhou')
    return root, en, jp


def load_backup_sources(data_dir):
    """Lê backup mínimo de 3 originais (EN TDF + BMF03/04).

    O quarto TDF japonês é OPCIONAL. Se ausente, utiliza apenas registros
    japoneses vazios com estrutura/IDs do EN; nunca inventa textos JP.
    """
    root = Path(data_dir)
    if (root / 'data' / EN_NAME).is_file():
        root = root / 'data'
    en_blob = read_known(root / EN_NAME, EN_NAME)
    for fontname in (FONT03_NAME, FONT04_NAME):
        read_known(root / fontname, fontname)
    en = parse_tdf(en_blob)
    if serialize_tdf(en) != en_blob:
        raise ValueError('Reconstrução exata do texto inglês original falhou')
    jp_file = root / JP_NAME
    if jp_file.exists():
        jp_blob = read_known(jp_file, JP_NAME)
        jp = parse_tdf(jp_blob)
        if serialize_tdf(jp) != jp_blob:
            raise ValueError('Reconstrução exata do japonês falhou')
        if any(a.markers != b.markers for a, b in zip(en, jp)):
            raise ValueError('Agrupamentos EN/JP divergentes')
    else:
        jp = [Section([''] * len(section.texts), section.markers) for section in en]
    return root, en, jp


def human_to_game(s, section):
    if section in (1, 2):
        mapping = {'ã':'a\ue210', 'õ':'o\ue211', 'ç':'c\ue212',
                   'á':'a\ue213', 'ú':'u\ue213', 'í':'i\ue214', 'ó':'o\ue215'}
    elif section == 3:
        mapping = {'ã':'a\ue100', 'õ':'o\ue101', 'ç':'c\ue102'}
    else:
        raise ValueError('Seção fora de 1..3')
    return ''.join(mapping.get(ch, ch) for ch in s)


def game_to_human(s, section):
    if section in (1, 2):
        mapping = {'a\ue210':'ã', 'o\ue211':'õ', 'c\ue212':'ç',
                   'a\ue213':'á', 'u\ue213':'ú', 'i\ue214':'í', 'o\ue215':'ó'}
    elif section == 3:
        mapping = {'a\ue100':'ã', 'o\ue101':'õ', 'c\ue102':'ç'}
    else:
        raise ValueError('Seção fora de 1..3')
    # Substituir pares completos, preservando códigos PUA desconhecidos.
    for seq, ch in mapping.items():
        s = s.replace(seq, ch)
    return s


# CSV V13 compatível: barras especiais devem ser escapadas e reversíveis.
def escape_cell(s):
    return s.replace('\\', '\\\\').replace('\r', '\\r').replace('\n', '\\n').replace('\t', '\\t')


def unescape_cell(s):
    if not isinstance(s, str):
        raise ValueError('Célula ausente')
    result = []
    i = 0
    xmap = {'n': '\n', 'r': '\r', 't': '\t', '\\': '\\'}
    while i < len(s):
        if s[i] == '\\':
            if i + 1 >= len(s) or s[i + 1] not in xmap:
                raise ValueError('Sequência de escape inválida: use \\n, \\r, \\t ou \\\\.')
            result.append(xmap[s[i + 1]])
            i += 2
        else:
            result.append(s[i])
            i += 1
    return ''.join(result)


def records(en, jp, translation=None, notes=None, erase=None):
    translation = translation or {}
    notes = notes or {}
    erase = erase or set()
    out = []
    for si, (en_sec, jp_sec) in enumerate(zip(en, jp), 1):
        group = 0
        markers = set(en_sec.markers)
        for i, (a, b) in enumerate(zip(en_sec.texts, jp_sec.texts)):
            if i in markers:
                group += 1
            key = (si, i)
            value = translation.get(key, '')
            if value and key in erase:
                raise ValueError('Apagar e substituir simultaneamente não é permitido')
            out.append({'id':'S{}_{:04d}'.format(si, i), 'secao':str(si),
                        'indice_0':str(i), 'grupo':str(group),
                        'ingles': escape_cell(a), 'japones': escape_cell(b),
                        'pt_br':escape_cell(value),
                        'acao':'APAGAR' if key in erase else '',
                        'observacoes':escape_cell(notes.get(key, ''))})
    return out


def write_csv(path, rows):
    path = Path(path)
    with path.open('x', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=COLS, delimiter=';', quoting=csv.QUOTE_MINIMAL)
        w.writeheader()
        w.writerows(rows)


def save_csv_with_backup(path, rows):
    """Sobrescreve apenas um CSV explicitamente escolhido, após preservar .backup_N.

    Nunca recebe arquivos TDF. O salvamento usa os.replace depois de escrita
    completa num arquivo temporário no mesmo diretório.
    """
    path=Path(path)
    if path.suffix.lower() != '.csv':
        raise ValueError('Salvar tradução somente em .csv')
    if not path.exists():
        write_csv(path,rows)
        return None
    if not path.is_file() or path.stat().st_size > MAX_FILE_SIZE:
        raise ValueError('CSV de destino inválido')
    old=path.read_bytes()
    back=None
    for i in range(1,10000):
        candidate=path.with_name(path.name+'.backup_{:04d}'.format(i))
        try:
            with candidate.open('xb') as f:
                f.write(old)
                f.flush();os.fsync(f.fileno())
            back=candidate
            break
        except FileExistsError:
            continue
    if back is None:
        raise ValueError('Número máximo de backups atingido')
    fd,tmp=tempfile.mkstemp(prefix='.nitro_csv_',suffix='.csv',dir=str(path.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8-sig',newline='') as f:
            writer=csv.DictWriter(f,fieldnames=COLS,delimiter=';',quoting=csv.QUOTE_MINIMAL)
            writer.writeheader();writer.writerows(rows)
            f.flush();os.fsync(f.fileno())
        if not Path(tmp).stat().st_size:
            raise IOError('CSV temporário vazio')
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)
    return back


def read_csv(path, en, jp):
    path = Path(path)
    # Usar utf-8-sig aceita CSV V13 e CSV novo, mas nunca decodificar com perda.
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        r = csv.DictReader(f, delimiter=';', strict=True)
        cols = r.fieldnames
        required = set(COLS) - {'acao'}
        if cols is None or not required.issubset(set(cols)):
            raise ValueError('Cabeçalhos CSV ausentes ou incompatíveis')
        if len(cols) != len(set(cols)):
            raise ValueError('Cabeçalhos duplicados no CSV')
        if set(cols) - set(COLS):
            raise ValueError('Colunas não previstas: ' + repr(set(cols)-set(COLS)))
        expected = {(rec['secao'], rec['indice_0']):rec for rec in records(en, jp)}
        seen = set()
        translations = {}
        notes = {}
        erasures = set()
        for n, row in enumerate(r, 2):
            if None in row:
                raise ValueError('CSV com colunas excedentes na linha {}'.format(n))
            if any(row.get(c) is None for c in cols):
                raise ValueError('CSV com célula ausente na linha {}'.format(n))
            k = (row['secao'], row['indice_0'])
            reference = expected.get(k)
            if reference is None or k in seen:
                raise ValueError('ID desconhecido ou duplicado em linha {}: {}'.format(n, row.get('id')))
            seen.add(k)
            for col in ('id','secao','indice_0','grupo'):
                if row[col] != reference[col]:
                    raise ValueError('Coluna estrutural alterada em {}: {}'.format(row['id'], col))
            if unescape_cell(row['ingles']) != unescape_cell(reference['ingles']):
                raise ValueError('Referência EN/JP (inglês) foi alterada em '+row['id'])
            # O quarto arquivo JP é opcional. CSV feito com JP
            # pode ser reaberto usando só o backup EN; seu JP NÃO é exibido
            # como original sem que o arquivo japonês seja verificado.
            # CSV feito sem JP também pode abrir quando o usuário acrescentá-lo.
            jp_in_csv=unescape_cell(row['japones'])
            jp_original=unescape_cell(reference['japones'])
            if jp_in_csv and jp_original and jp_in_csv != jp_original:
                raise ValueError('Referência japonesa divergente em '+row['id'])
            pt = unescape_cell(row['pt_br'])
            note = unescape_cell(row['observacoes'])
            if note:
                notes[(int(k[0]),int(k[1]))] = note
            action = (row.get('acao') or '').strip().upper()
            if action not in ('', 'APAGAR'):
                raise ValueError('Ação desconhecida no registro ' + row['id'])
            key = (int(k[0]), int(k[1]))
            if action == 'APAGAR':
                if pt:
                    raise ValueError('APAGAR exige pt_br vazia em ' + row['id'])
                erasures.add(key)
            elif pt:
                check_translation(pt, key)
                translations[key] = pt
        if seen != set(expected):
            missing = set(expected) - seen
            raise ValueError('CSV incompleto: faltam {} entradas, por exemplo {}'.format(len(missing), sorted(missing)[:3]))
    return translations, notes, erasures


def check_translation(t, key):
    if '\x00' in t or '\r' in t or '\t' in t:
        raise ValueError('PT-BR contém NUL, CR ou TAB em S{}_{:04d}'.format(*key))
    try:
        n = len(human_to_game(t, key[0]).encode('utf-16le', 'strict')) // 2
    except UnicodeError as e:
        raise ValueError('Unicode inválido em S{}_{:04d}'.format(*key)) from e
    if n > MAX_UNITS:
        raise ValueError('Tamanho de texto excede o limite em S{}_{:04d}'.format(*key))


def load_vj51_delta(delta_path, en):
    """Extrai somente traduções do catálogo VJ51 ORIGINAL, sem executar seu instalador."""
    p = Path(delta_path)
    if p.suffix.lower() == '.zip':
        with zipfile.ZipFile(p) as z:
            names = z.namelist()
            if names.count('DELTA_PTBR_VJ51.json') != 1:
                raise ValueError('ZIP VJ51 sem DELTA_PTBR_VJ51.json único')
            info = z.getinfo('DELTA_PTBR_VJ51.json')
            if info.file_size > 1000000:
                raise ValueError('Delta dentro do ZIP maior que o limite')
            b = z.read(info)
    else:
        if p.stat().st_size > 1000000:
            raise ValueError('Delta JSON maior que o limite')
        b = p.read_bytes()
    if sha(b) != VJ51_SHA:
        raise ValueError('O DELTA_PTBR_VJ51.json não tem o SHA-256 conhecido: importação bloqueada.')
    data = json.loads(b.decode('utf-8'))
    if data.get('sha_tdf_final') != VJ51_TDF_SHA or len(data.get('registros', [])) != 3373:
        raise ValueError('Catálogo VJ51 inesperado')
    result = {}
    for rec in data['registros']:
        si, i, pt = rec['secao'], rec['indice'], rec['ptbr']
        if type(si) is not int or type(i) is not int or not (1 <= si <= 3 and 0 <= i < EXPECTED_COUNTS[si-1]):
            raise ValueError('Posição inválida no catálogo')
        k = (si, i)
        if k in result or not isinstance(pt, str):
            raise ValueError('Duplicado ou texto inválido no catálogo')
        result[k] = game_to_human(pt, si)
        check_translation(result[k], k)
    patched = apply_translations(en, result)
    if sha(serialize_tdf(patched)) != VJ51_TDF_SHA:
        raise ValueError('Reconstrução de VJ51 divergente! A importação foi rejeitada.')
    return result


def apply_translations(en, translations, erasures=None):
    erasures = erasures or set()
    if not set(translations).isdisjoint(erasures):
        raise ValueError('Conflito entre substituição e APAGAR')
    out = [Section(list(s.texts), s.markers) for s in en]
    for (si, i), text in translations.items():
        if si < 1 or si > 3 or i < 0 or i >= len(out[si-1].texts):
            raise ValueError('Registro fora da tabela')
        check_translation(text, (si, i))
        out[si-1].texts[i] = human_to_game(text, si)
    for si, i in erasures:
        if si < 1 or si > 3 or i < 0 or i >= len(out[si-1].texts):
            raise ValueError('Registro para apagar fora da tabela')
        out[si-1].texts[i] = ''
    return out


def audit_texts(en, translated):
    # Avisos não são erros; não existe métrica definitiva de largura das caixas de diálogo.
    warnings = []
    changed = []
    for si, (a, b) in enumerate(zip(en, translated), 1):
        for i, (old, new) in enumerate(zip(a.texts, b.texts)):
            if old == new:
                continue
            rid = 'S{}_{:04d}'.format(si, i)
            changed.append(rid)
            if '\x00' in new:
                raise ValueError('NUL gerado em ' + rid)
            if new.count('\n') > 2 and si in (1,2):
                warnings.append(rid + ': acima de 3 linhas; conferir no jogo')
            old_longest = max((len(x) for x in old.split('\n')), default=0)
            new_longest = max((len(x) for x in new.split('\n')), default=0)
            if new_longest > max(80, old_longest * 2):
                warnings.append(rid + ': linha muito maior que o inglês; conferir caixa')
            for ch in set(new):
                if 0xe000 <= ord(ch) <= 0xf8ff:
                    allowed = ({0xe100,0xe101,0xe102} if si==3 else
                               {0xe210,0xe211,0xe212,0xe213,0xe214,0xe215})
                    if ord(ch) not in allowed:
                        warnings.append(rid + ': código privado não reconhecido U+{:04X}'.format(ord(ch)))
    return changed, warnings


# BMF originais e conversão de fontes PT-BR VJ51, conforme a implementação verificada.
BMF_FMT = '<IHHHHhhhBB3s'
BMF_REC_LEN = struct.calcsize(BMF_FMT)
DONORS = (0x101, 0x1CE, 0x1D2)
PRIVATE_IDS = (0xE100, 0xE101, 0xE102)
PUA_04 = {
    0xE210:(ord('~'), -10, 4),
    0xE211:(ord('~'), -11, 4),
    0xE212:(ord(','), -9, 22),
    0xE213:(ord("'"), -6, 3),
    0xE214:(ord("'"), -3, 1),
    0xE215:(ord("'"), -7, 3),
}

def bmf_blocks(raw):
    if not raw.startswith(b'BMF\x03'):
        raise ValueError('Fonte não é BMF3')
    blocks=[]
    pos=4
    while pos < len(raw):
        if pos + 5 > len(raw):
            raise ValueError('BMF incompleta')
        ident, n = struct.unpack_from('<BI', raw, pos)
        start, end = pos + 5, pos + 5 + n
        if end > len(raw):
            raise ValueError('Bloco BMF fora do arquivo')
        blocks.append((ident, raw[start:end]))
        pos = end
    if sum(k == 4 for k,_ in blocks) != 1:
        raise ValueError('Fonte BMF sem tabela única de glifos')
    return blocks


def bmf_rows(payload, expected=None):
    if len(payload) % BMF_REC_LEN:
        raise ValueError('Tabela de glifos truncada')
    rows = [list(struct.unpack_from(BMF_FMT, payload, x)) for x in range(0,len(payload),BMF_REC_LEN)]
    ids = [r[0] for r in rows]
    if ids != sorted(ids) or len(set(ids)) != len(ids):
        raise ValueError('IDs de glifos inválidos')
    if expected is not None and len(rows) != expected:
        raise ValueError('Quantidade de glifos não corresponde ao original')
    return rows


def patch_font03(raw):
    if sha(raw) != KNOWN_SHA[FONT03_NAME]:
        raise ValueError('BMF03 não é original')
    blocks=bmf_blocks(raw)
    if sum(k==4 for k,_ in blocks)!=1:
        raise ValueError('BMF03 incompatível')
    output=[]
    for typ,payload in blocks:
        if typ==4:
            rows=bmf_rows(payload,143)
            r={x[0]:x for x in rows}
            if not all(c in r for c in DONORS+ (ord('~'),ord(','))):
                raise ValueError('Glifos doadores faltando BMF03')
            new=[]
            overlay=[(DONORS[0],PRIVATE_IDS[0],ord('~'),-16,4),
                     (DONORS[2],PRIVATE_IDS[1],ord('~'),-16,4),
                     (DONORS[1],PRIVATE_IDS[2],ord(','),-9,24)]
            sub={old:(code,src,dx,dy) for old,code,src,dx,dy in overlay}
            for row in rows:
                if row[0] not in sub:
                    new.append(row)
                else:
                    code,src,dx,dy=sub[row[0]]
                    glyph=r[src].copy()
                    glyph[0]=code;glyph[5]=dx;glyph[6]=dy;glyph[7]=0
                    new.append(glyph)
            new.sort(key=lambda v:v[0]); bmf_rows(b''.join(struct.pack(BMF_FMT,*row) for row in new),143)
            payload=b''.join(struct.pack(BMF_FMT,*row) for row in new)
        output.append(struct.pack('<BI',typ,len(payload))+payload)
    result=b'BMF\x03'+b''.join(output)
    if len(result)!=len(raw):
        raise AssertionError('Tamanho BMF03 inesperado')
    return result


def patch_font04(raw):
    if sha(raw)!=KNOWN_SHA[FONT04_NAME]:
        raise ValueError('BMF04 não é original')
    out=[]
    for typ,payload in bmf_blocks(raw):
        if typ == 4:
            rows=bmf_rows(payload,86)
            dic={r[0]:r for r in rows}
            if not all(src in dic for src,_,_ in PUA_04.values()):
                raise ValueError('Glifos doadores ausentes BMF04')
            if any(code in dic for code in PUA_04):
                raise ValueError('Glifos privados existentes BMF04')
            for code,(src,dx,dy) in PUA_04.items():
                glyph=dic[src].copy();glyph[0]=code;glyph[5]=dx;glyph[6]=dy;glyph[7]=0
                rows.append(glyph)
            rows.sort(key=lambda v:v[0]);payload=b''.join(struct.pack(BMF_FMT,*r) for r in rows)
            bmf_rows(payload,92)
        out.append(struct.pack('<BI',typ,len(payload))+payload)
    result=b'BMF\x03'+b''.join(out)
    if len(result)!=len(raw) + 6*BMF_REC_LEN:
        raise AssertionError('Tamanho BMF04 inesperado')
    return result


def make_build(en, translations, erasures=None):
    result = apply_translations(en, translations, erasures)
    changed, warnings = audit_texts(en, result)
    binary = serialize_tdf(result)
    parsed = parse_tdf(binary)
    if not same_structure(parsed, result):
        raise AssertionError('Releitura do TDF gerado não corresponde aos textos')
    # NENHUMA alteração fora dos registros autorizados.
    intended = set(translations) | set(erasures or set())
    actual = {(s,i) for s, (before, after) in enumerate(zip(en,parsed),1)
              for i,(x,y) in enumerate(zip(before.texts,after.texts)) if x!=y}
    if not actual.issubset(intended):
        raise AssertionError('Campo não autorizado foi modificado')
    return binary, changed, warnings


def create_outputs(base_dir, output_dir, en, jp, translations, erasures=None, make_fonts=True):
    """Gerar arquivos numa pasta separada; NUNCA substituir game/data ou saída existente."""
    base_dir=Path(base_dir).resolve()
    dest=Path(output_dir).resolve()
    if dest == base_dir or dest in base_dir.parents or base_dir in dest.parents:
        raise ValueError('Saída deve estar fora da pasta de originais/jogo')
    if dest.exists() and (dest / EN_NAME).exists():
        raise FileExistsError('Saída já contém um TDF! Escolha pasta nova.')
    if dest.exists() and any((dest / n).exists() for n in (FONT03_NAME, FONT04_NAME,'RELATORIO_GERACAO.json')):
        raise FileExistsError('Saída já possui arquivos com esses nomes. Nada foi sobrescrito.')
    if (base_dir / EN_NAME).resolve()==(dest / EN_NAME).resolve():
        raise ValueError('Destino é o arquivo original!')
    # Revalidar os arquivos de origem imediatamente antes de gerar.
    current_root, current_en, current_jp = load_backup_sources(base_dir)
    if not same_structure(en, current_en) or not same_structure(jp, current_jp):
        raise ValueError('As fontes de entrada mudaram desde o carregamento')
    text_bytes, changed, warnings = make_build(en, translations, erasures)
    files = {EN_NAME:text_bytes}
    if make_fonts:
        files[FONT03_NAME] = patch_font03(read_known(current_root / FONT03_NAME, FONT03_NAME))
        files[FONT04_NAME] = patch_font04(read_known(current_root / FONT04_NAME, FONT04_NAME))
    if make_fonts:
        # Checar glifos TTF/BMF da tradução. Algumas teclas são ícones processados
        # pelo jogo e não constam das BMF; portanto esses códigos são exceções.
        button_symbols = set(''.join(chr(cp) for cp in range(0x2460,0x24ff)))
        glyphs = {}
        for sec, fontname in ((1,FONT04_NAME),(2,FONT04_NAME),(3,FONT03_NAME)):
            glyphs[sec] = {row[0] for kind,payload in bmf_blocks(files[fontname])
                           if kind == 4 for row in bmf_rows(payload)}
        out_sections = parse_tdf(text_bytes)
        for si, sec in enumerate(out_sections, 1):
            for idx, new in enumerate(sec.texts):
                if new == en[si-1].texts[idx]:
                    continue
                missing = {ch for ch in new if ord(ch) not in glyphs[si]
                           and ch not in '\n\r\t' and ch not in button_symbols}
                if missing:
                    warnings.append('S{}_{:04d}: possíveis caracteres ausentes da fonte: {}'.format(
                        si,idx,', '.join('U+{:04X}'.format(ord(ch)) for ch in sorted(missing))))
    manifest = {'programa':'Nitroplus Blasterz - Tradutor Manual V1.12',
                'originais_verificados':{k:KNOWN_SHA[k] for k in ((EN_NAME,JP_NAME) if (current_root/JP_NAME).is_file() else (EN_NAME,))},
                'fontes_geradas':make_fonts,
                'registros_totais':sum(EXPECTED_COUNTS),
                'registros_modificados':len(changed),
                'ids_modificados':changed,
                'avisos':warnings,
                'arquivos_gerados':{name:sha(raw) for name,raw in files.items()},
                'instrucao':'Estes arquivos são apenas saídas locais, NÃO foram instalados. Faça backup antes de instalar manualmente.'}
    dest.mkdir(parents=True, exist_ok=True)
    # Criação exclusiva: se existir algum arquivo, parar antes de iniciar qualquer gravação.
    if any((dest/name).exists() for name in files):
        raise FileExistsError('Um dos arquivos de destino já existe; cancelado sem sobrescrever.')
    created=[]
    try:
        for name, b in files.items():
            file=dest/name
            with file.open('xb') as f:
                f.write(b)
                f.flush();os.fsync(f.fileno())
            created.append(file)
            if sha(file.read_bytes())!=sha(b):
                raise IOError('Falha de verificação após gravação de ' + name)
    except Exception:
        for file in created:
            file.unlink(missing_ok=True)
        raise
    return manifest

# Instalador de revisões produzidas localmente: cópia de segurança verificável,
# geração isolada, substituição atômica por arquivo e restauração controlada.
def _write_new_bytes(path, content):
    path=Path(path)
    with path.open('xb') as f:
        f.write(content);f.flush();os.fsync(f.fileno())
    if path.read_bytes()!=content:
        raise IOError('Gravação divergente: '+str(path))


def _replace_verified(destination, content):
    """Grava ao lado do alvo e usa replace no mesmo sistema de arquivos."""
    destination=Path(destination)
    fd, tempname=tempfile.mkstemp(prefix='.nitro_ptbr_',suffix='.tmp',dir=str(destination.parent))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(content);f.flush();os.fsync(f.fileno())
        if sha(Path(tempname).read_bytes()) != sha(content):
            raise IOError('Arquivo temporário não confere')
        os.replace(tempname,destination)
    finally:
        if os.path.exists(tempname):os.unlink(tempname)
    if sha(destination.read_bytes())!=sha(content):
        raise IOError('Arquivo instalado não confere: '+str(destination))


def _backup_root_check(backup_root, game_root):
    backup_root=Path(backup_root).resolve()
    game_root=Path(game_root).resolve()
    if backup_root==game_root or game_root in backup_root.parents:
        raise ValueError('Backups devem ficar FORA da pasta data do jogo.')
    if backup_root == game_root.parent:
        raise ValueError('Escolha uma pasta de backup fora da raiz do jogo.')
    return backup_root


def _game_data_root(game_dir):
    d=Path(game_dir).resolve()
    if (d/'data'/EN_NAME).exists():d=d/'data'
    names=(EN_NAME,JP_NAME,FONT03_NAME,FONT04_NAME)
    for n in names:
        p=d/n
        if not p.is_file() or p.is_symlink():
            raise ValueError('Falta arquivo ou é link simbólico no destino: '+str(p))
    # A versão japonesa nunca é alterada pelo editor e confirma o destino.
    read_known(d/JP_NAME,JP_NAME)
    return d


def _get_install_state(backup_root):
    p=Path(backup_root)/'ESTADO_INSTALACAO.json'
    if not p.exists():return {}
    if p.stat().st_size>1048576:raise ValueError('Estado de instalações muito grande')
    x=json.loads(p.read_text(encoding='utf-8'))
    if not isinstance(x,dict):raise ValueError('Estado de instalações inválido')
    return x


def _update_state(backup_root, state):
    path=Path(backup_root)/'ESTADO_INSTALACAO.json'
    data=json.dumps(state,ensure_ascii=False,indent=2).encode('utf-8')
    fd,tmp=tempfile.mkstemp(prefix='.estado_',dir=str(backup_root))
    try:
        with os.fdopen(fd,'wb') as f:
            f.write(data);f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)


def install_translation(source_base, game_dir, backup_root, en, jp, translations, erasures=None):
    """Gera arquivos de edição e instala com backup. Retorna localização dos originais preservados.

    Política: só sobrescreve originais, VJ51, 1.0 final conhecida, ou arquivos
    exatamente iguais aos que uma instalação anterior registrou.
    """
    from datetime import datetime
    from uuid import uuid4
    source_base=Path(source_base).resolve()
    game=_game_data_root(game_dir)
    backup=_backup_root_check(backup_root,game)
    if backup==source_base:
        raise ValueError('Pasta de backups não pode ser a mesma pasta dos originais.')
    _,check_en,check_jp=load_backup_sources(source_base)
    if not same_structure(en,check_en) or not same_structure(jp,check_jp):
        raise ValueError('Os arquivos de origem mudaram. Instalação cancelada.')
    generated_names=(EN_NAME,FONT03_NAME,FONT04_NAME)
    current_bytes={n:(game/n).read_bytes() for n in generated_names}
    current_hashes={n:sha(current_bytes[n]) for n in generated_names}
    known_original=all(current_hashes[n]==KNOWN_SHA[n] for n in generated_names)
    known_vj51=(current_hashes=={
        EN_NAME:VJ51_TDF_SHA,
        FONT03_NAME:'55ae305e5e01a73c5f4cbdfa1898bca80283c01036eba3f3ea7e448d2d10b908',
        FONT04_NAME:'9236f7565d9de9baa8c2c751657b4014fb685963a3de149016779f1406497891'})
    # Autorizar TAMBÉM a 1.0 final pública se e somente se os hashes dos
    # três arquivos instalados forem EXATAMENTE os do manifesto verificado.
    # Isso permite editar a versão 1.0 já instalada sem desproteger outros mods.
    known_final_10=(current_hashes=={
        EN_NAME:FINAL_10_TDF_SHA,
        FONT03_NAME:'55ae305e5e01a73c5f4cbdfa1898bca80283c01036eba3f3ea7e448d2d10b908',
        FONT04_NAME:'9236f7565d9de9baa8c2c751657b4014fb685963a3de149016779f1406497891'})
    state=_get_install_state(backup)
    record=state.get(str(game),{})
    known_previous=record.get('installed_sha')==current_hashes
    if not (known_original or known_vj51 or known_final_10 or known_previous):
        raise ValueError('Instalação contém arquivos diferentes dos originais, VJ51, PT-BR 1.0 final ou último teste deste editor.\n'
                         'Para não perder outros mods/trabalhos, restaure arquivos conhecidos antes.')
    # O usuário nunca precisa voltar a abrir a pasta data já modificada: originais limpos ficam guardados.
    backup.mkdir(parents=True,exist_ok=True)
    originals=backup/'ORIGINAIS_LIMPOS'
    originals.mkdir(exist_ok=True)
    # Backup dos 3 arquivos usados na edição; JP é guardado somente se
    # estiver disponível como original íntegro (não faz parte da instalação).
    backup_names=[EN_NAME,FONT03_NAME,FONT04_NAME]
    optional_jp=source_base/JP_NAME
    if optional_jp.is_file():
        backup_names.append(JP_NAME)
    for n in backup_names:
        p=originals/n
        expected=read_known(source_base/n,n)
        if not p.exists():
            _write_new_bytes(p,expected)
        else:
            if read_known(p,n)!=expected:
                raise ValueError('Originais limpos divergentes na pasta de backups: '+n)
    install_id=datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:8]
    generated=backup/'GERADOS'/install_id
    genmanifest=create_outputs(source_base,generated,en,jp,translations,erasures,make_fonts=True)
    new_bytes={n:(generated/n).read_bytes() for n in generated_names}
    if any(sha(new_bytes[n])!=genmanifest['arquivos_gerados'][n] for n in generated_names):
        raise IOError('Arquivo gerado divergente de manifesto; instalação cancelada')
    save_dir=backup/'INSTALACOES'/install_id
    save_dir.mkdir(parents=True,exist_ok=False)
    for n in generated_names:_write_new_bytes(save_dir/n,current_bytes[n])
    metadata={
        'id':install_id,'destino_data':str(game),'originais_preservados':str(originals),
        'tabela_salva_pelo_usuario':False, 'sha_anteriores':current_hashes,
        'sha_instalados':{n:sha(new_bytes[n]) for n in generated_names},
        'arquivos_gerados':str(generated),'registros_modificados':genmanifest['registros_modificados'],
        'avisos':genmanifest['avisos']
    }
    _write_new_bytes(save_dir/'RELATORIO_INSTALACAO.json',json.dumps(metadata,indent=2,ensure_ascii=False).encode('utf-8'))
    changed=[]
    try:
        # Verificar de novo imediatamente antes de cada gravação. Jogo deve estar fechado.
        for n in generated_names:
            if sha((game/n).read_bytes())!=current_hashes[n]:
                raise IOError('Arquivo de jogo alterado durante a instalação: '+n)
            _replace_verified(game/n,new_bytes[n])
            changed.append(n)
        state[str(game)]={'installed_sha':metadata['sha_instalados'],'last_install':install_id}
        _update_state(backup,state)
    except Exception as exc:
        errors=[]
        for n in reversed(changed):
            try:_replace_verified(game/n,current_bytes[n])
            except Exception as e:errors.append('{}: {}'.format(n,e))
        if errors:
            raise IOError('INSTALAÇÃO FALHOU e restauração incompleta. Backups em '+str(save_dir)+'. '+str(errors)) from exc
        raise IOError('Instalação cancelada e arquivos anteriores restaurados. '+str(exc)) from exc
    return metadata


def restore_last_install(game_dir, backup_root):
    """Restaura só se o jogo ainda tiver os hashes da última instalação do editor."""
    game=_game_data_root(game_dir)
    backup=_backup_root_check(backup_root,game)
    state=_get_install_state(backup)
    old=state.get(str(game),{})
    install_id=old.get('last_install')
    if not install_id or not re.fullmatch(r'\d{8}_\d{6}_[a-f0-9]{8}',install_id):
        raise ValueError('Nenhuma instalação ativa registrada para este jogo nesta pasta de backups.')
    savedir=backup/'INSTALACOES'/install_id
    meta=json.loads((savedir/'RELATORIO_INSTALACAO.json').read_text(encoding='utf-8'))
    names=(EN_NAME,FONT03_NAME,FONT04_NAME)
    if meta['destino_data']!=str(game):
        raise ValueError('Backup é de outro jogo/pasta')
    if any(sha((game/n).read_bytes())!=meta['sha_instalados'][n] for n in names):
        raise ValueError('Jogo mudou depois da última instalação! Restauração automática bloqueada.')
    restored={n:(savedir/n).read_bytes() for n in names}
    if any(sha(restored[n])!=meta['sha_anteriores'][n] for n in names):
        raise IOError('Backup não corresponde ao relatório')
    now={n:(game/n).read_bytes() for n in names}
    changed=[]
    try:
        for n in names:
            _replace_verified(game/n,restored[n]);changed.append(n)
        state[str(game)]={'installed_sha':meta['sha_anteriores'],'last_install':None}
        _update_state(backup,state)
    except Exception as e:
        for n in reversed(changed):
            _replace_verified(game/n,now[n])
        raise IOError('Restauração falhou; arquivos instalados recolocados: '+str(e)) from e
    return {'jogo':str(game),'backup':str(savedir),'originais_ou_versao_anterior':meta['sha_anteriores']}
