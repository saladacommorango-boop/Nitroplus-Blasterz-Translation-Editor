"""Importador SOMENTE-LEITURA da tradução PT-BR 1.0 do usuário.

Não executa o instalador distribuído. Confere o manifesto, os hashes e
reconstrói o TDF em memória antes de devolver as traduções para o CSV.
Não substitui o núcleo seguro de reinserção.
"""
import gzip
import json
import struct
import zipfile
from pathlib import Path

import nitro_core as core

PATCH_10_TDF_SHA = 'd0b23506c313240abd22e4560f22810127951ac81a73c6ed60492efac6c2d7d9'
PATCH_10_PATCH_SHA = '074a4d016a40a8651c17c0deb75bff2598ac29120cd3ec4320c97d7547473359'
PATCH_10_NAME = 'Nitroplus Blasterz PT-BR 1.0'


def read_10_texts(zip_path, base, en):
    """(traduções, apagamentos); lança ValueError se o patch não for esperado."""
    with zipfile.ZipFile(zip_path) as z:
        if z.namelist().count('MANIFESTO_1_0.json') != 1 or z.namelist().count('texto.ptbz') != 1:
            raise ValueError('O ZIP não contém um manifesto ou texto.ptbz único.')
        manifest_info = z.getinfo('MANIFESTO_1_0.json')
        patch_info = z.getinfo('texto.ptbz')
        if manifest_info.file_size > 100_000 or patch_info.file_size > 1_000_000:
            raise ValueError('Manifesto ou patch com tamanho inesperado.')
        manifest = json.loads(z.read('MANIFESTO_1_0.json').decode('utf-8-sig'))
        if manifest.get('versao') != PATCH_10_NAME:
            raise ValueError('Esta não é a tradução Nitroplus PT-BR 1.0 conhecida.')
        ent = manifest['arquivos']['texto']
        if (ent['nome'] != core.EN_NAME or ent['patch'] != 'texto.ptbz'
                or ent['original_sha256'] != core.KNOWN_SHA[core.EN_NAME]
                or ent['ptbr_sha256'] != PATCH_10_TDF_SHA
                or ent['patch_sha256'] != PATCH_10_PATCH_SHA):
            raise ValueError('O manifesto não corresponde à versão 1.0 verificada.')
        compressed = z.read('texto.ptbz')
    if core.sha(compressed) != PATCH_10_PATCH_SHA:
        raise ValueError('Hash do patch 1.0 divergente.')
    try:
        raw = gzip.decompress(compressed)
    except (OSError, EOFError) as exc:
        raise ValueError('Dados compactados inválidos no texto.ptbz.') from exc
    if len(raw) > 3_000_000 or len(raw) < 16:
        raise ValueError('Patch binário acima do tamanho permitido.')
    magic, version, source_length, dest_length = struct.unpack_from('<4sIII', raw)
    source = core.read_known(Path(base) / core.EN_NAME, core.EN_NAME)
    if magic != b'NTPD' or version != 1 or source_length != len(source) or dest_length > core.MAX_FILE_SIZE:
        raise ValueError('Cabeçalho NTPD incompatível.')
    output = bytearray()
    pos = 16
    while pos < len(raw):
        op = raw[pos]
        pos += 1
        if pos + 4 > len(raw):
            raise ValueError('Operação NTPD incompleta.')
        n, = struct.unpack_from('<I', raw, pos)
        pos += 4
        if op == 0:
            if pos + 4 > len(raw):
                raise ValueError('Cópia NTPD incompleta.')
            length, = struct.unpack_from('<I', raw, pos)
            pos += 4
            if n + length > len(source):
                raise ValueError('Cópia NTPD fora dos limites do original.')
            output.extend(source[n:n + length])
        elif op == 1:
            if pos + n > len(raw):
                raise ValueError('Texto literal NTPD truncado.')
            output.extend(raw[pos:pos + n])
            pos += n
        else:
            raise ValueError('Operação NTPD desconhecida.')
        if len(output) > dest_length:
            raise ValueError('Patch NTPD excedeu o tamanho declarado.')
    if len(output) != dest_length or core.sha(output) != PATCH_10_TDF_SHA:
        raise ValueError('SHA-256 do TDF final 1.0 não corresponde ao manifesto.')
    patched = core.parse_tdf(output)
    if any(p.markers != original.markers for p, original in zip(patched, en)):
        raise ValueError('Patch contém alteração nos agrupamentos originais.')
    translations = {}
    erasures = set()
    for section, (original, target) in enumerate(zip(en, patched), 1):
        for index, (previous, updated) in enumerate(zip(original.texts, target.texts)):
            if previous != updated:
                key = (section, index)
                if not updated:
                    erasures.add(key)
                else:
                    human = core.game_to_human(updated, section)
                    core.check_translation(human, key)
                    translations[key] = human
    rebuilt, _, _ = core.make_build(en, translations, erasures)
    if rebuilt != output:
        raise ValueError('O editor não conseguiu reconstruir o conteúdo exato da 1.0.')
    return translations, erasures
